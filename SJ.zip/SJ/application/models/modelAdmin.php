<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ModelAdmin extends CI_Model {

	public function login($username, $password){
		//echo $username.$password;
		$sql = "SELECT id_admin, username, password
				FROM admin 
				WHERE username = '".$username."' AND password = '".$password."' ";
		$data =$this->db->query( $sql );
		if ($data->num_rows()>0) {
			foreach ($data->result_array() as $row) {
				$sess = array( 	'id'		=> $row['id_admin'],
								'username'	=> $row['username'],
								'password'	=> $row['password'],
								'akses'		=> 'admin'	);
				$this->session->set_userdata($sess);
				redirect('admin');
			}
		}
		else {
			$this->session->set_flashdata('warnLoginAdmin','Maaf, username atau password yang dimasukkan salah. Silahkan login kembali.');
			redirect('controlVisitor/login');
		}
	}

}
