<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ModelPaket extends CI_Model {

	//menambhakan paket baru
	public function addPaket($paket){
		$sql = 'SELECT * FROM paket WHERE nama_paket = "'.$paket['nama_paket'].'"';
		$kondisi = $this->db->query($sql);
		if ($kondisi->num_rows>=1) {
			$sql = 'DELETE FROM pilihan_paket where id_pilihan_paket = "'.$paket['id_pilihan_paket'].'"';
			$this->db->query($sql);
			$this->session->set_flashdata('infoWarning',"Maaf tidak dapat menambahkan paket baru karena nama paket 
				sudah ada dalam sistem. Silahkan isi form kembali.");
			redirect('admin/tambahPaket');
		} else {
			$result = $this->db->insert('paket',$paket);
			$this->session->set_flashdata('infoSuccess',"Paket berhasil ditambahkan.");
			redirect('admin/listPaket');
		}
	}

	//menampilkan semua daftar list paket dan informasinya untuk admin
	public function getListPaket(){
		$sql = 'SELECT P.id_paket, P.id_pilihan_destinasi, P.nama_paket, P.info_paket, P.foto, P.harga_paket, P.waktu, P.agama,
		PP.id_destinasi1, ( SELECT nama_destinasi FROM destinasi D RIGHT JOIN pilihan_destinasi A ON id_destinasi1 = D.id_destinasi WHERE A.id_pilihan_destinasi = P.id_pilihan_destinasi) as destinasi1,
		PP.id_destinasi2, ( SELECT nama_destinasi FROM destinasi D RIGHT JOIN pilihan_destinasi A ON id_destinasi2 = D.id_destinasi WHERE A.id_pilihan_destinasi = P.id_pilihan_destinasi) as destinasi2,
		PP.id_destinasi3, ( SELECT nama_destinasi FROM destinasi D RIGHT JOIN pilihan_destinasi A ON id_destinasi3 = D.id_destinasi WHERE A.id_pilihan_destinasi = P.id_pilihan_destinasi) as destinasi3,
		PP.id_destinasi4, ( SELECT nama_destinasi FROM destinasi D RIGHT JOIN pilihan_destinasi A ON id_destinasi4 = D.id_destinasi WHERE A.id_pilihan_destinasi = P.id_pilihan_destinasi) as destinasi4,
		PP.id_destinasi5, ( SELECT nama_destinasi FROM destinasi D RIGHT JOIN pilihan_destinasi A ON id_destinasi5 = D.id_destinasi WHERE A.id_pilihan_destinasi = P.id_pilihan_destinasi) as destinasi5
		FROM paket P
		JOIN pilihan_destinasi PP ON P.id_pilihan_destinasi = PP.id_pilihan_destinasi';
		$result = $this->db->query($sql);
		if ($result->num_rows()>=1) {
			return $result->result_array();
		} else return 'data not found';
	}

	public function getPaketDetail($id){
		$sql = 'SELECT P.id_paket, P.id_pilihan_destinasi, P.nama_paket, P.info_paket, P.foto, P.harga_paket, P.waktu, P.agama,
		PP.id_destinasi1, ( SELECT nama_destinasi FROM destinasi D RIGHT JOIN pilihan_destinasi A ON id_destinasi1 = D.id_destinasi WHERE A.id_pilihan_destinasi = P.id_pilihan_destinasi) as destinasi1,
		( SELECT foto_destinasi FROM destinasi D RIGHT JOIN pilihan_destinasi A ON id_destinasi1 = D.id_destinasi WHERE A.id_pilihan_destinasi = P.id_pilihan_destinasi) as foto1,
		PP.id_destinasi2, ( SELECT nama_destinasi FROM destinasi D RIGHT JOIN pilihan_destinasi A ON id_destinasi2 = D.id_destinasi WHERE A.id_pilihan_destinasi = P.id_pilihan_destinasi) as destinasi2,
		( SELECT foto_destinasi FROM destinasi D RIGHT JOIN pilihan_destinasi A ON id_destinasi2 = D.id_destinasi WHERE A.id_pilihan_destinasi = P.id_pilihan_destinasi) as foto2,
		PP.id_destinasi3, ( SELECT nama_destinasi FROM destinasi D RIGHT JOIN pilihan_destinasi A ON id_destinasi3 = D.id_destinasi WHERE A.id_pilihan_destinasi = P.id_pilihan_destinasi) as destinasi3,
		( SELECT foto_destinasi FROM destinasi D RIGHT JOIN pilihan_destinasi A ON id_destinasi3 = D.id_destinasi WHERE A.id_pilihan_destinasi = P.id_pilihan_destinasi) as foto3,
		PP.id_destinasi4, ( SELECT nama_destinasi FROM destinasi D RIGHT JOIN pilihan_destinasi A ON id_destinasi4 = D.id_destinasi WHERE A.id_pilihan_destinasi = P.id_pilihan_destinasi) as destinasi4,
		( SELECT foto_destinasi FROM destinasi D RIGHT JOIN pilihan_destinasi A ON id_destinasi4 = D.id_destinasi WHERE A.id_pilihan_destinasi = P.id_pilihan_destinasi) as foto4,
		PP.id_destinasi5, ( SELECT nama_destinasi FROM destinasi D RIGHT JOIN pilihan_destinasi A ON id_destinasi5 = D.id_destinasi WHERE A.id_pilihan_destinasi = P.id_pilihan_destinasi) as destinasi5,
		( SELECT foto_destinasi FROM destinasi D RIGHT JOIN pilihan_destinasi A ON id_destinasi5 = D.id_destinasi WHERE A.id_pilihan_destinasi = P.id_pilihan_destinasi) as foto5
		FROM paket P
		JOIN pilihan_destinasi PP ON P.id_pilihan_destinasi = PP.id_pilihan_destinasi
		WHERE p.id_paket = "'.$id.'"';
		$result = $this->db->query($sql);
		if ($result->num_rows()>=1) {
			return $result->result_array();
		} else return 'data not found';
	}

	//mendapatkan data paket berdasarkan id yang dimasukkan
	public function getPaket($id){
		$sql = 'SELECT id_paket, id_pilihan_destinasi, nama_paket, harga_paket, waktu, agama 
		FROM paket WHERE id_paket = "'.$id.'"';
		$result = $this->db->query($sql);
		if ($result->num_rows()>=1) {
			return $result->result_array();
		} else return 'data not found';
	}

	//menghapus paket
	public function deletePaket($paket){
		$sql = 'DELETE FROM paket WHERE id_paket = "'.$paket['id_paket'].'"'; //untuk hapus paket
		$result = $this->db->query($sql);
		if (!$result) {
			$this->session->set_flashdata('InfoWarning',"Maaf tidak dapat menghapus paket");
			redirect('admin/listPaket');
		} else { //jika paket berhasi dihapus
			$sql = 'DELETE FROM pilihan_destinasi WHERE id_pilihan_destinasi = "'.$paket['id_pilihan_destinasi'].'"'; //hapus pilihan destinasi paket
			$result = $this->db->query($sql);
			$this->session->set_flashdata('infoSuccess',"Paket berhasil dihapus");
			redirect('admin/listPaket');
		}
	}

	//mengedit paket
	public function editPaket($paket){
		$this->db->where('id_paket',$paket['id_paket']);
		$result = $this->db->update('paket',$paket);
		if (!$result) {
			$this->session->set_flashdata('InfoWarning',"Maaf tidak dapat mengedit paket");
			redirect('admin/listPaket');
		} else {
			$this->session->set_flashdata('infoSuccess',"Paket berhasil diedit");
			redirect('admin/listPaket');
		}
	}

}
