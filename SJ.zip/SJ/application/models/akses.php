<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Akses extends CI_Model {

	public function getAksesMember(){
		$akses = $this->session->userdata('akses');
		if ($akses != 'member') {
			$this->session->sess_destroy();
			echo "
				<script>
					alert('Maaf tidak dapat mengakses halaman member'); location = 'controlVisitor';
				</script>
			";
		}
	}

	public function getAksesAdmin(){
		$akses = $this->session->userdata('akses');
		if ($akses != 'admin') {
			$this->session->sess_destroy();
			echo "
				<script>
					alert('Maaf tidak dapat mengakses halaman admin'); location = 'controlVisitor';
				</script>
			";
		}
	}

	
}
