<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ModelPemesanan extends CI_Model {

	//membuat pemesanan baru
	public function addWisatawan($wisatawan){
		$result = $this->db->insert('wisatawan',$wisatawan);
		$sql = 'SELECT id_wisatawan FROM wisatawan 
		WHERE wisatawan1 ="'.$wisatawan['wisatawan1'].'" AND wisatawan2 ="'.$wisatawan['wisatawan2'].'"AND wisatawan3 ="'.$wisatawan['wisatawan3'].'" ';
		$result = $this->db->query($sql);
		return $result->result_array();
	}

	public function addPemesanan($pemesanan){
		$this->db->insert('pemesanan',$pemesanan);
		$kondisi = $this->db->get_where('pemesanan',$pemesanan);
		if (!$kondisi) {
			$this->session->set_flashdata('infoWarning',"Maaf tidak dapat memproses pemesanan Anda. Silahkan pesan kembali.");
			redirect('member/daftarPesanan');
		} else {
			$this->session->set_flashdata('infoSuccess',"Pemesanan paket wisata berhasil dibuat.");
			redirect('member/daftarPesanan');
		}
	}

	public function getListPemesanan($id){
		$sql = 'SELECT ps.id_pesan, p.id_paket, p.nama_paket, ps.nama_pemesan, p.harga_paket, p.waktu, 
				ps.tanggal_berangkat, ps.provinsi, ps.kota, ps.alamat_pemesan,ps.id_wisatawan, ps.id_member
				FROM pemesanan ps
				LEFT JOIN paket p ON p.id_paket = ps.id_paket
				WHERE ps.id_member = "'.$id.'"';
		$result = $this->db->query($sql);
		if ($result->num_rows()>=1) {
			return $result->result_array();
		} else return 'data not found';
	}

	public function getPesanan($id){
		$sql = 'SELECT ps.id_pesan, p.id_paket, p.nama_paket, ps.nama_pemesan, ps.provinsi, ps.kota, ps.alamat_pemesan, ps.nomor_telepon, 
		ps.email, ps.tanggal_berangkat, ps.jumlah_wisatawan, p.harga_paket, p.waktu, ps.id_wisatawan, ps.id_member, 
		(SELECT wisatawan1 from wisatawan w RIGHT JOIN pemesanan ps ON w.id_wisatawan = ps.id_wisatawan WHERE ps.id_pesan = "'.$id.'") as wisatawan1, 
		(SELECT wisatawan2 from wisatawan w RIGHT JOIN pemesanan ps ON w.id_wisatawan = ps.id_wisatawan  WHERE ps.id_pesan = "'.$id.'" ) as wisatawan2, 
		(SELECT wisatawan3 from wisatawan w RIGHT JOIN pemesanan ps ON w.id_wisatawan = ps.id_wisatawan  WHERE ps.id_pesan = "'.$id.'" ) as wisatawan3
		FROM pemesanan ps
		LEFT JOIN paket p ON p.id_paket = ps.id_paket
		WHERE ps.id_pesan = "'.$id.'" ';
		$result = $this->db->query($sql);
		if (!$result) {
			return 'data not found';
		} else {
			return $result->result_array();
		}
	}

	public function deletePesanan($pesanan){
		$sql = 'DELETE FROM pemesanan WHERE id_pesan = "'.$pesanan['id_pesan'].'"'; //untuk hapus pesanan
		$result = $this->db->query($sql);
		if (!$result) {
			$this->session->set_flashdata('InfoWarning',"Maaf tidak dapat membatalkan pemesanan");
			redirect('member/daftarPesanan');
		} else { //jika paket berhasi dihapus
			$sql = 'DELETE FROM wisatawan WHERE id_wisatawan = "'.$pesanan['id_wisatawan'].'"'; //hapus pilihan destinasi paket
			$result = $this->db->query($sql);
			$this->session->set_flashdata('infoSuccess',"Pemesanan berhasil dibatalkan");
			redirect('member/daftarPesanan');
		}
	}

	
}
	