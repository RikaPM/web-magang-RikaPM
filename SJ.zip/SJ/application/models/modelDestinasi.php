<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ModelDestinasi extends CI_Model {

	public function addDestinasi($data){

		$this->db->where('nama_destinasi',$data['nama_destinasi']);
		$kondisi = $this->db->get('destinasi');
		if ($kondisi->num_rows>=1) {
			$this->session->set_flashdata('infoWarning',"Maaf tidak dapat menambahkan destinasi karena data destinasi sudah ada dalam sistem. 
				Silahkan isi form kembali.");
			redirect('admin/tambahDestinasi');
		} else {
			$result = $this->db->insert('destinasi',$data);
			$this->session->set_flashdata('infoSuccess',"Destinasi berhasil ditambahkan.");
			redirect('admin');
		}
	}

	public function tambahPilihanDestinasi($data){
		$sql = 'SELECT *
		from pilihan_destinasi where id_destinasi1 = "'.$data['id_destinasi1'].'" 
		and id_destinasi2 = "'.$data['id_destinasi2'].'" 
		and id_destinasi3 = "'.$data['id_destinasi3'].'" 
		and id_destinasi4 = "'.$data['id_destinasi4'].'"
		and id_destinasi5 = "'.$data['id_destinasi5'].'"';
		$kondisi = $this->db->query($sql);
		if ($kondisi->num_rows()>=1) {
			$this->session->set_flashdata('infoWarning',"Maaf tidak dapat menambahkan pilihan destinasi karena data pilihan destinasi sudah ada dalam sistem. 
				Silahkan isi form kembali.");
			redirect('admin/tambahPaket');
		} else {
			$this->db->insert('pilihan_destinasi',$data);
			$sql = 'SELECT id_pilihan_destinasi from pilihan_destinasi where id_destinasi1 = "'.$data['id_destinasi1'].'" 
			and id_destinasi2 = "'.$data['id_destinasi2'].'" 
			and id_destinasi3 = "'.$data['id_destinasi3'].'" 
			and id_destinasi4 = "'.$data['id_destinasi4'].'"
			and id_destinasi5 = "'.$data['id_destinasi5'].'"';
			$pilihanDestinasi = $this->db->query($sql);
			$result = $pilihanDestinasi->result_array();
			return $result;
		}
	}

	public function getFoto() {
		$sql = "SELECT foto_destinasi FROM destinasi";
		$data = $this->db->query( $sql );
		$result = $data->result_array();
		if ($data->num_rows()>=1) {
			return $result;
		} else return 'data not found';
	}
	
	public function loadAgama() {
		$sql = "SELECT DISTINCT agama from destinasi order by agama";
		$data = $this->db->query($sql);
		$result = $data->result_array();
		if ($data->num_rows()>=1) {
			return $result;
		} else return 'data not found';
	}

	public function loadDestinasi($agama) {
		$sql = "SELECT id_destinasi, nama_destinasi, agama from destinasi where agama = '".$agama."'";
		$data = $this->db->query($sql);
		$result = $data->result_array();
		if ($data->num_rows()>=1) {
			return $result;
		} else return 'data not found';
	}

	public function getDestinasi($id_destinasi){
		$sql = "SELECT id_destinasi, nama_destinasi, agama from destinasi where id_destinasi = '".$id_destinasi."'";
		$data = $this->db->query($sql);
		$result = $data->result_array();
		if ($data->num_rows()>=1) {
			return $result;
		} else return 'data not found';
	}

	public function getListDestinasi(){
		$sql = "SELECT id_destinasi,nama_destinasi,agama from destinasi";
		$data = $this->db->query($sql);
		$result = $data->result_array();
		if ($data->num_rows()>=1) {
			return $result;
		} else return 'data not found';
	}
/*
	public function getProvinsi() {
		$sql = "SELECT DISTINCT provinsi from destinasi";
		$data = $this->db->query($sql);
		$result = $data->result_array();
		if ($data->num_rows()>=1) {
			return $result;
		} else return 'data not found';
	}

	public function getJsonDestinasi(){
		$sql = "SELECT id_destinasi,nama_destinasi,agama from destinasi";
		$data = $this->db->query($sql);
		$result = $data->result_array();
		if ($data->num_rows()>=1) {
			return json_encode($result);
		} else return 'data not found';
	}	
*/


}
