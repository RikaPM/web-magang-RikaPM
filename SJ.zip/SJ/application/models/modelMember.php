<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ModelMember extends CI_Model {

	public function createMember($data){
		$this->db->where('username',$data['username']);
		$kondisi = $this->db->get('member');
		if ($kondisi->num_rows()>=1) {
			$this->session->set_flashdata('infoWarning',"Maaf tidak dapat menambah member, username sudah ada dalam sistem. Silahkan isi dengan username yang berbeda.");
			redirect( 'controlVisitor/registrasi');
		}
		else{
			$result = $this->db->insert('member',$data);
			$sql = "SELECT id_member, username, password, nama, email, provinsi, kota, alamat, telepon
				FROM member 
				WHERE username = '".$data['username']."' AND password = '".$data['password']."' ";
			$data =$this->db->query( $sql );
			if ($data->num_rows()>0) {
				foreach ($data->result_array() as $row) {
					$sess = array( 	'id_member'	=> $row['id_member'],
									'username'	=> $row['username'],
									'password'	=> $row['password'],
									'nama'		=> $row['nama'],
									'email'		=> $row['email'],
									'provinsi'	=> $row['provinsi'],
									'kota'		=> $row['kota'],
									'alamat'	=> $row['alamat'],
									'telepon'	=> $row['telepon'],
									'akses'		=> 'member'	);
					$this->session->set_userdata($sess);
					redirect('member');
					}
			}
			else {
				$this->session->set_flashdata('warnLoginMember','Maaf, data yang dimasukkan salah. Silahkan registrasi kembali.');
				redirect('controlVisitor/registrasi');
			}
		}
	}

	public function login($username, $password){
		echo $username.$password.'<br>';
		$sql = "SELECT id_member, username, password, nama, email, provinsi, kota, alamat, telepon
				FROM member 
				WHERE username = '".$username."' AND password = '".$password."' ";
		$data =$this->db->query( $sql );
		echo $data->num_rows();
		if ($data->num_rows()>0) {
			foreach ($data->result() as $row) {
				$sess = array( 	'id_member'		=> $row->id_member,
								'username'	=> $row->username,
								'password'	=> $row->password,
								'nama'		=> $row->nama,
								'email'		=> $row->email,
								'provinsi'	=> $row->provinsi,
								'kota'		=> $row->kota,
								'alamat'	=> $row->alamat,
								'telepon'	=> $row->telepon,
								'akses'		=> 'member'	);
				$this->session->set_userdata($sess);
				redirect('member');
			}
		}
		else {
			$this->session->set_flashdata('warnLoginMember','Maaf, username atau password yang dimasukkan salah. Silahkan login kembali.');
			redirect('controlVisitor/login');
		}
	}

}
