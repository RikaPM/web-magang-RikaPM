<div class="container daftar-paket">
	<div class="paket-info">
		<h2>Daftar Paket</h2>
	</div>
	<div class="row clearfix">
	<?php 
		foreach ($paket as $paket) { ?>
		<div class="col-md-4 col-daftar-paket">
			<a href="<?php echo site_url(); ?>/<?php echo $control; ?>/HalamanPaket/?id=<?php echo $paket['id_paket']; ?>">
				<img class="img-daftar-paket" alt="<?php echo $paket['foto']; ?>" src="<?php echo base_url().$paket['foto']; ?>" />
			</a>
			<div class="info-daftar-paket">
				<h4 class="judul-daftar-paket"><?php echo $paket['nama_paket']; ?></h4>
				<p>Harga paket : <?php echo $paket['harga_paket']; ?></p>
				<p>Lama Perjalanan :<?php echo $paket['waktu']; ?> hari</p>
			</div>
		</div>
	<?php } ?>
	</div>
</div>