<!-- gallery -->
	<div class="gallery-top">
			<!-- container -->
			<div class="container">
				<div class="gallery-info">
					<h2>Gallery</h2>
				</div>
				<div class="gallery-grids-top">
					<div class="gallery-grids gallery-grids-middle">
						<?php 

						foreach ($foto as $foto) {
							echo '
						<div class="col-md-3 gallery-grid">
							<a class="example-image-link" href="'.base_url().$foto['foto_destinasi'].'" data-lightbox="example-set" data-title="">
							<img class="example-image" src="'.base_url().$foto['foto_destinasi'].'" alt="'.$foto['foto_destinasi'].'"/></a>
						</div>';
						}


						?>
						<div class="clearfix"> </div>
					</div>
					<script src="<?php echo base_url(); ?>js/lightbox-plus-jquery.min.js"></script>
				</div>
			</div>
			<!-- //container -->
	</div>
	<!-- //gallery -->