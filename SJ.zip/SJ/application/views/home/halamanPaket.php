<div class="container halaman-paket">
	<!-- gambar paket ambil dari destinasi -->
<?php 
	foreach ($paket as $paket) { ?>
	<div class="carousel slide" id="carousel-paket">
		<div class="carousel-inner">
			<div class="item active">
				<img alt="<?php echo $paket['foto']; ?>" src="<?php echo base_url().$paket['foto']; ?>" />
				<div class="carousel-caption">
					<h4><?php echo $paket['nama_paket']; ?></h4>
				</div>
			</div>
			<div class="item">
				<img alt="<?php echo $paket['foto1']; ?>" src="<?php echo base_url().$paket['foto1']; ?>" />
				<div class="carousel-caption">
					<h4><?php echo $paket['destinasi1']; ?></h4>
				</div>
			</div>
			<div class="item">
				<img alt="<?php echo $paket['foto2']; ?>" src="<?php echo base_url().$paket['foto2']; ?>" />
				<div class="carousel-caption">
					<h4><?php echo $paket['destinasi2']; ?></h4>
				</div>
			</div>
			<div class="item">
				<img alt="<?php echo $paket['foto3']; ?>" src="<?php echo base_url().$paket['foto3']; ?>" />
				<div class="carousel-caption">
					<h4><?php echo $paket['destinasi3']; ?></h4>
				</div>
			</div>
			<div class="item">
				<img alt="<?php echo $paket['foto4']; ?>" src="<?php echo base_url().$paket['foto4']; ?>" />
				<div class="carousel-caption">
					<h4><?php echo $paket['destinasi4']; ?></h4>
				</div>
			</div>
			<div class="item">
				<img alt="<?php echo $paket['foto5']; ?>" src="<?php echo base_url().$paket['foto5']; ?>" />
				<div class="carousel-caption">
					<h4><?php echo $paket['destinasi5']; ?></h4>
				</div>
			</div>
		</div> <a class="left carousel-control" href="#carousel-paket" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a> <a class="right carousel-control" href="#carousel-paket" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
	</div>
	<h2><?php echo $paket['nama_paket']; ?></h2>
	<!-- informasi paket -->
	<div class="tabbable" id="tabs-1944">
		<ul class="nav nav-tabs">
			<li class="active">
				<a href="#panel-info-paket" data-toggle="tab">Informasi Paket</a>
			</li>
<?php 	if (!empty($data)) {	?>
			<li>
				<a href="#panel-info-pemesanan" data-toggle="tab">Pemesanan Paket</a>
			</li>
<?php 	} ?>
		</ul>
		<div class="tab-content">
			<!-- informasi paket -->
			<div class="tab-pane active" id="panel-info-paket">
				<table class="table-info-paket">
					<tr>
						<td>Nama Paket</td>
						<td>:</td>
						<td><?php echo $paket['nama_paket']; ?></td>
					</tr>
					<tr>
						<td>Harga Paket</td>
						<td>:</td>
						<td><?php echo $paket['harga_paket']; ?></td>
					</tr>
					<tr>
						<td>Lama Perjalanan</td>
						<td>:</td>
						<td><?php echo $paket['waktu']; ?></td>
					</tr>
					<tr>
						<td>Destinasi Tujuan</td>
						<td>:</td>
						<td>
							<ul>
								<li><?php echo $paket['destinasi1']; ?></li>
								<li><?php echo $paket['destinasi2']; ?></li>
								<li><?php echo $paket['destinasi3']; ?></li>
								<li><?php echo $paket['destinasi4']; ?></li>
								<li><?php echo $paket['destinasi5']; ?></li>
							</ul>
						</td>
					</tr>
				</table>
				<div class="info-paket">
					<?php echo $paket['info_paket']; ?>
				</div>
			</div>
<?php 	if (!empty($data)) {	?>
			<!-- informasi pemesanan paket -->
			<div class="tab-pane" id="panel-info-pemesanan">
				<form class="form-horizontal" role="form" method="POST" action="<?php echo site_url() ?>/member/formPesanan">
					<input type="hidden" class="form-control" name="idPaket" value="<?php echo $paket['id_paket']; ?>" />
					<div class="form-group">
						<label class="col-sm-3 control-label">
							Tanggal Keberangkatan
						</label>
						<div class="col-sm-9">
							<input type="date" class="form-control" name="tanggalBerangkat" />
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-3 control-label">
							Jumlah Wisatawan
						</label>
						<div class="col-sm-9">
							<select name="jumlahWisatawan" required>
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<div class="col-sm-offset-2 col-sm-10">
							<button type="submit" class="btn btn-default">Pesan Paket</button>
						</div>
					</div>
				</form>
			</div>
<?php 	} ?>
		</div>
	</div>
<?php 	} ?>	
</div>