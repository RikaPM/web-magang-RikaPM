<div class="container konfirmasi">
	<p>Silahkan cek data di bawah apakah sesuai dengan data yang Anda masukkan sebelumnya. Jika tidak klik Kembali.</p>
	<p><i>Jika ingin membatalkan proses registrasi, klik Batal</i></p>
	<form class="form-konfirmasi" role="form" method="POST" action="<?php echo site_url(); ?>/controlRegister/buatMember">
	<table class="table-info-paket">
	<?php 
		
			echo '
		<tr>
			<td>Username</td>
			<td>:</td>
			<td><input readonly type="text" class="form-control" name="username" value="'.$data['username'].'" /></td>
		</tr>
		<tr>
			<td>Password</td>
			<td>:</td>
			<td><input readonly type="password" class="form-control" name="password" value="'.$data['password'].'" /></td>
		</tr>
		<tr>
			<td>Nama</td>
			<td>:</td>
			<td>
				<input readonly required type="text" class="form-control" name="nama" value="'.$data['nama'].'" />
			</td>
		</tr>
		<tr>
			<td>Email</td>
			<td>:</td>
			<td>
				<input readonly required type="email" class="form-control" name="email" value="'.$data['email'].'" />
			</td>
		</tr>
		<tr>
			<td>Provinsi</td>
			<td>:</td>
			<td>
				<input readonly required type="text" class="form-control" name="provinsi" value="'.$data['provinsi'].'" />
			</td>
		</tr>
		<tr>
			<td>Kota</td>
			<td>:</td>
			<td>
				<input readonly required type="text" class="form-control" name="kota" value="'.$data['kota'].'" />
			</td>
		</tr>
		<tr>
			<td>alamat</td>
			<td>:</td>
			<td>
				<textarea readonly required class="input-alamat" name="alamat">'.$data['alamat'].'</textarea>
			</td>
		</tr>
		<tr>
			<td>Telepon</td>
			<td>:</td>
			<td>
				<input readonly required type="tel" class="form-control" name="telepon" value="'.$data['telepon'].'" />
			</td>
		</tr>';
		 ?>
	</table>
	<div class="checkbox">					 
		<label>
			<input required type="checkbox" /> <i>Dengan ini saya menyetujui semua syarat dan ketentuan untuk 
			menjadi member website Spiritual Journey.</i>
		</label>
	</div>
	<!--
	<a href="#"><span class="label label-default">Kembali</span></a> 
	<a href="#"><span class="label label-danger">Batal</span></a>
	-->
	<button class="btn btn-default" onclick="goBack()">
		Kembali
	</button>
	<button type="submit" class="btn btn-default">
		Registrasi
	</button>
	<button class="btn btn-default batal"> <a href="<?php echo site_url(); ?>">
		Batal </a>
	</button>
	</form>
</div>

<script type="text/javascript">
	function goBack(){
		history.go(-1);
		return false;
	}
</script>