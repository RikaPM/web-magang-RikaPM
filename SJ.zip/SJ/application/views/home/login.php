<div class="container login-admin">
	<div class="tabbable" id="tabs-1944">
		<ul class="nav nav-tabs">
			<li class="active">
				<a href="#panel-login-member" data-toggle="tab">Login Member</a>
			</li>
			<li>
				<a href="#panel-login-admin" data-toggle="tab">Login Admin</a>
			</li>
		</ul>
		<div class="tab-content">
			<!-- login member -->
			<div class="tab-pane active" id="panel-login-member">
				<div class="gallery-info">
					<h2>Login Member</h2>
				</div>
				<div class="form-login">
				<center>
					<form method="POST" action="<?php echo site_url(); ?>/login/logMember">
						<div class="form-group"> 
							<label>
								Username
							</label>
							<input required type="text" class="form-control" name="username" />
						</div>
						<div class="form-group">
							<label>
								Password
							</label>
							<input required type="password" class="form-control" name="password" />
						</div>
						<div class="info-warning">
							<?php
								$info = $this->session->flashdata('warnLoginMember');
								if (!empty($info)) {
									echo $info;
								}
							?>
						</div>
						<button type="submit" class="btn btn-default">
							Login
						</button>
					</form>
				</center>
				</div>
			</div>
			<!-- login admin -->
			<div class="tab-pane" id="panel-login-admin">
				<div class="gallery-info">
					<h2>Login Admin</h2>
				</div>
				<div class="form-login">
				<center>
					<form method="POST" action="<?php echo site_url(); ?>/login/logAdmin">
						<div class="form-group"> 
							<label>
								Username
							</label>
							<input required type="text" class="form-control" name="username" />
						</div>
						<div class="form-group">
							<label>
								Password
							</label>
							<input required type="password" class="form-control" name="password" />
						</div>
						<div class="info-warning">
						<?php
							$info = $this->session->flashdata('warnLoginAdmin');
							if (!empty($info)) {
								echo $info;
							}
						?>
						</div>
						<button type="submit" class="btn btn-default">
							Login
						</button>
					</form>
				</center>
				</div>
			</div>
		</div>
	</div>
</div>