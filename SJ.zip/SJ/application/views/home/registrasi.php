<div class="container registrasi">
	<div class="gallery-info">
		<h2>Registrasi</h2>
	</div>
	<div class="form-catatan">
		<p>silahkan isi form di bawah in iuntuk menjadi member baru dalam web kami.</p>
		<p>*semua field form harus diisi</p>
	</div>
	<div class="info-warning">
	<?php
		$info = $this->session->flashdata('infoWarning');
		if (!empty($info)) {
			echo $info;
		}
	?>
	</div>
	<div class="form-registrasi">
		<form role="form" method="POST" action="<?php echo site_url(); ?>/controlRegister">
			<div class="form-group"> 
				<label>
					Username
				</label>
				<input required type="text" class="form-control" name="username" />
			</div>
			<div class="form-group">
				<label>
					Password
				</label>
				<input required type="password" class="form-control" name="password" />
			</div>
			<div class="form-group"> 
				<label>
					Nama Lengkap
				</label>
				<input required type="text" class="form-control" name="nama" />
			</div>
			<div class="form-group"> 
				<label>
					Email
				</label>
				<input required type="email" class="form-control" name="email" />
			</div>
			<div class="form-group"> 
				<label>
					Provinsi
				</label>
				<input required type="text" class="form-control" name="provinsi" />
			</div>
			<div class="form-group"> 
				<label>
					Kota
				</label>
				<input required type="text" class="form-control" name="kota" />
			</div>
			<div class="form-group"> 
				<label>
					Alamat
				</label> <br>
				<textarea required class="input-alamat" name="alamat"></textarea>
			</div>
			<div class="form-group"> 
				<label>
					Nomor Telepon
				</label>
				<input required type="tel" class="form-control" name="telepon" />
			</div>
			<button type="submit" class="btn btn-default">
				Submit
			</button>
		</form>
	</div>
</div>