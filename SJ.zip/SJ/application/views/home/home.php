<!-- welcome -->
	<div class="welcome">
		<!-- container -->
		<div class="container">
			<div class="welcome-info">
				<h2>Selamat Datang</h2>
				<p>Selamat datang dalam website Spiritual Jourrney. Di sini anda dapat melihat beragam informasi mengenai pariwisata
				khususnya wisata religi.</p>
				<p>Kami menyediakan layanan pemesanan paket perjalanan wisata dari destinasi yang ada di Pulau Jawa dan Bali.</p>
			</div>
		</div>
		<!-- //container -->
	</div>
	<!-- //welcome -->
	<!-- slider -->
	<div class="slider">
		<div class="arrival-grids">			 
			 <ul id="flexiselDemo1">
	 <?php 	foreach ($foto as $foto) { ?>
				 <li>
					 <a href="<?php site_url().$control ?>/gallery"><img src="<?php echo base_url().$foto['foto_destinasi']; ?>" alt=""/>
					 </a>
				 </li>
		<?php 	} ?>
				</ul>
				<script type="text/javascript">
				 $(window).load(function() {			
				  $("#flexiselDemo1").flexisel({
					visibleItems: 5,
					animationSpeed: 1000,
					autoPlay: true,
					autoPlaySpeed: 3000,    		
					pauseOnHover:true,
					enableResponsiveBreakpoints: true,
					responsiveBreakpoints: { 
						portrait: { 
							changePoint:480,
							visibleItems: 1
						}, 
						landscape: { 
							changePoint:640,
							visibleItems: 2
						},
						tablet: { 
							changePoint:768,
							visibleItems: 3
						}
					}
				});
				});
				</script>
				<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.flexisel.js"></script>			 
		</div>
	</div>
	<!-- //slider -->
	<!-- news-bottom -->
	<div class="news-bottom">
		<!-- container -->
		<div class="container">
			<div class="news-bottom-info">
				<h3>Spiritual Journey</h3>
				<p>Selamat datang dalam website Spiritual Jourrney. Di sini anda dapat melihat beragam informasi mengenai pariwisata
				khususnya wisata religi.</p>
				<p>Kami menyediakan layanan pemesanan paket perjalanan wisata dari destinasi yang ada di Pulau Jawa dan Bali.</p>
			</div>
		</div>
		<!-- //container -->
	</div>
	<!-- //news-bottom -->
	