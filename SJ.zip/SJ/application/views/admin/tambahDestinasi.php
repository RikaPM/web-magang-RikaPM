<div class="container halaman-tambah-destinasi">
	<div class="paket-info">
		<h2>Tambah Destinasi</h2>
	</div>
<?php
	$infoSuccess = $this->session->flashdata('infoSuccess');
	if (!empty($info)) {
		echo '
		<div class="alert alert-success" role="alert">
			'.$infoSuccess.'
		</div>
		';
	}

	$infoWarning = $this->session->flashdata('infoWarning');
	if (!empty($infoWarning)) {
		echo '
		<div class="alert alert-danger" role="alert">
			'.$infoWarning.'
		</div>
		';
	}

?>
	<div class="form-catatan">
		<p>Isi form di bawah ini untuk menambah destinasi baru ke dalam sistem</p>
		<p>*semua field form harus diisi</p>
	</div>
	<div class="form-tambah-destinasi">
		<form role="form" method="POST" action="<?php echo site_url(); ?>/destinasi/tambahDestinasi" enctype="multipart/form-data">
			<div class="form-group"> 
				<label>
					Nama Destinasi
				</label>
				<input required type="text" class="form-control" name="nama" />
			</div>
			<div class="form-group"> 
				<label>
					Provinsi
				</label>
				<input required type="text" class="form-control" name="provinsi" />
			</div>
			<div class="form-group"> 
				<label>
					Kota
				</label>
				<input required type="text" class="form-control" name="kota" />
			</div>
			<div class="form-group"> 
				<label>
					Alamat Destinasi
				</label> <br>
				<textarea required class="input-alamat" name="alamat"></textarea>
			</div>
			<div class="form-group"> 
				<label>
					Kategori Destinasi
				</label>
				<div>
				<select required name="agama" >
					<option value="islam">Islam</option>
					<option value="kristen">Kristen</option>
					<option value="budha">Budha</option>
					<option value="hindu">Hindu</option>
				</select>
				</div>
			</div>
			<div class="form-group"> 
				<label>
					Informasi Destinasi
				</label> <br>
				<textarea required class="input-info" name="infoDestinasi"></textarea>
			</div>
			<div class="form-group"> 
				<label>
					File foto
				</label>
				<input type="file" name="fotoDestinasi" id="fotoDestinasi" accept="image/jpeg" required placeholder="IMAGE URL"><br>
				<p class="help-block">
					Masukan file foto destinasi yang ditambahkan
				</p>
			</div>
			<button type="submit" class="btn btn-default">
				Tambah Destinasi
			</button>
		</form>
	</div>
</div>

