<div class="container halaman-list-paket">
	<div class="paket-info">
		<h2>List Paket</h2>
	</div>
<?php
	$infoSuccess = $this->session->flashdata('infoSuccess');
	if (!empty($infoSuccess)) {
		echo '
		<div class="alert alert-success" role="alert">
			'.$infoSuccess.'
		</div>
		';
	}

	$infoWarning = $this->session->flashdata('infoWarning');
	if (!empty($infoWarning)) {
		echo '
		<div class="alert alert-danger" role="alert">
			'.$infoWarning.'
		</div>
		';
	}

?>
	<div class="list-paket">
	<table class="table">
		<thead>
			<th>No.</th>
			<th class="hidden">ID Paket</th>
			<th>Nama Paket</th>
			<th>Harga Paket</th>
			<th>Lama Perjalanan</th>
			<th>Kategori Paket</th>
			<th>Action</th>
		</thead>
		<tbody>
		<?php 
			$nomor = 1;
			foreach ($listPaket as $paket) {
				echo '
					<tr>
					<td>'.$nomor.'</td>
					<td class="hidden">'.$paket['id_paket'].'</td>
					<td>'.$paket['nama_paket'].'</td>
					<td>'.$paket['harga_paket'].'</td>
					<td>'.$paket['waktu'].' hari</td>
					<td>'.$paket['agama'].'</td>
					<td>
						<a id="modal-hapus-paket" href="#modal-container-hapus-paket-'.$paket['id_paket'].'" 
						role="button" data-toggle="modal">
						<button type="submit" class="btn btn-default" >Hapus Paket</button></a>
						<a href="'.site_url().'/admin/editPaket/?id='.$paket['id_paket'].'">
						<button type="submit" class="btn btn-default">Edit Paket</button></a>
					</td>
				</tr>
				';
				$nomor++;
			}
		?>
		</tbody>
	</table>
	</div>

<?php	
	foreach ($listPaket as $paket) { ?>
	<div class="modal fade" id="modal-container-hapus-paket-<?php echo $paket['id_paket'] ?>" 
	role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
						×
					</button>
					<h4 class="modal-title" id="myModalLabel">
						Hapus Paket
					</h4>
				</div>
				<div class="modal-body">
					<table class="table-info-paket">
						<tr>
							<td>Nama Paket</td><td>:</td><td><?php echo $paket['nama_paket'] ?></td>
						</tr>
						<tr>
							<td>Pilihan Destinasi</td><td>:</td>
							<td>
								<ol>
									<li><?php echo $paket['destinasi1'] ?></li>
									<li><?php echo $paket['destinasi2'] ?></li>
									<li><?php echo $paket['destinasi3'] ?></li>
									<li><?php echo $paket['destinasi4'] ?></li>
									<li><?php echo $paket['destinasi5'] ?></li>
								</ol>
							</td>
						</tr>
						<tr>
							<td>Harga Paket</td><td>:</td><td><?php echo $paket['harga_paket'] ?></td>
						</tr>
						<tr>
							<td>Lama Perjalanan</td><td>:</td><td><?php echo $paket['waktu'] ?></td>
						</tr>
						<tr>
							<td>Kategori Paket</td><td>:</td><td><?php echo $paket['agama'] ?></td>
						</tr>
						<tr>
							<td>Info Paket</td><td>:</td><td><?php echo $paket['info_paket'] ?></td>
						</tr>
					</table>
					<span><p>Apakah anda ingin menghapus <?php echo $paket['nama_paket'] ?>?</p></span>
				</div>
				<div class="modal-footer">
					 
					<button type="button" class="btn btn-default" data-dismiss="modal">
						Batal
					</button>
					<a href="<?php echo site_url(); ?>/paket/hapusPaket/?id=<?php echo $paket['id_paket'] ?>&id_pilihan_destinasi=
					<?php echo $paket['id_pilihan_destinasi'] ?>">
						<button type="button" class="btn btn-primary">
							Hapus Paket
						</button>
					</a>
				</div>
			</div>
		</div>
	</div>
	<?php 
	} ?>
	
</div>
