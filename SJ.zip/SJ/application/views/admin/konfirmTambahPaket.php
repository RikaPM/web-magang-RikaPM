<div class="container konfirmasi">
	<p>Silahkan cek data di bawah apakah sesuai dengan data yang Anda masukkan sebelumnya. Jika tidak klik Kembali.</p>
	<p><i>Jika ingin membatalkan proses tambah paket, klik Batal</i></p>
	<form role="form" class="form-konfirmasi" method="POST" action="<?php echo site_url(); ?>/paket/tambahPaket" enctype="multipart/form-data">
	<table class="table-info-paket">
	<?php 
		foreach ($destinasi1 as $row) {
			echo '
		<tr>
			<td>Destinasi 1</td>
			<td>:</td>
			<td><input readonly type="hidden" class="form-control" name="destinasi1" value="'.$row['id_destinasi'].'" />
			<input readonly type="text" class="form-control" value="'.$row['nama_destinasi'].'" /></td>
		</tr>';
		}

		foreach ($destinasi2 as $row) {
			echo '
		<tr>
			<td>Destinasi 2</td>
			<td>:</td>
			<td><input readonly type="hidden" class="form-control" name="destinasi2" value="'.$row['id_destinasi'].'" />
			<input readonly type="text" class="form-control" value="'.$row['nama_destinasi'].'" /></td>
		</tr>';
		}

		foreach ($destinasi3 as $row) {
			echo '
		<tr>
			<td>Destinasi 3</td>
			<td>:</td>
			<td><input readonly type="hidden" class="form-control" name="destinasi3" value="'.$row['id_destinasi'].'" />
			<input readonly type="text" class="form-control" value="'.$row['nama_destinasi'].'" /></td>
		</tr>';
		}
		foreach ($destinasi4 as $row) {
			echo '
		<tr>
			<td>Destinasi 4</td>
			<td>:</td>
			<td><input readonly type="hidden" class="form-control" name="destinasi4" value="'.$row['id_destinasi'].'" />
			<input readonly type="text" class="form-control" value="'.$row['nama_destinasi'].'" /></td>
		</tr>';
		}
		foreach ($destinasi5 as $row) {
			echo '
		<tr>
			<td>Destinasi 5</td>
			<td>:</td>
			<td><input readonly type="hidden" class="form-control" name="destinasi5" value="'.$row['id_destinasi'].'" />
			<input readonly type="text" class="form-control" value="'.$row['nama_destinasi'].'" /></td>
		</tr>';
		}
			echo '
		<tr>
			<td>Nama Paket</td>
			<td>:</td>
			<td><input readonly type="text" class="form-control" name="namaPaket" value="'.$paket['nama_paket'].'" /></td>
		</tr>
		<tr>
			<td>Harga</td>
			<td>:</td>
			<td>
				<input readonly required type="text" class="form-control" name="harga" value="'.$paket['harga_paket'].'" />
			</td>
		</tr>
		<tr>
			<td>Lama Perjalanan</td>
			<td>:</td>
			<td>
				<input readonly required type="text" class="form-control" name="waktu" value="'.$paket['waktu'].'" />
			</td>
		</tr>
		<tr>
			<td>Kategori Paket</td>
			<td>:</td>
			<td>
				<input readonly required type="text" class="form-control" name="agama" value="'.$paket['agama'].'" />
			</td>
		</tr>
		<tr>
			<td>Informasi Paket</td>
			<td>:</td>
			<td>
				<textarea readonly required class="input-alamat" name="infoPaket">'.$paket['info_paket'].'</textarea>
			</td>
		</tr>
		<tr>
			<td>Foto</td>
			<td>:</td>
			<td> 
			<div class="form-group">
			<input type="file" name="fotoPaket" id="fotoPaket" accept="image/jpeg" required placeholder="IMAGE URL"/>
				<p class="help-block">
					Masukan file foto paket yang ditambahkan
				</p>
			</div>
			</td>
		</tr>';
		 ?>
	</table>
	<button class="btn btn-default" onclick="goBack()">
		Kembali
	</button>
	<button type="submit" class="btn btn-default">
		Tambah Paket
	</button>
	<button class="btn btn-default batal"> <a href="<?php echo site_url(); ?>/admin">
		Batal </a>
	</button>
	</form>
</div>

<script type="text/javascript">
	function goBack(){
		history.go(-1);
		return false;
	}
</script>