	<label>Pilihan agama : </label>
	<select name="pilih-destinasi" id="pilih-destinasi">
		<?php
	    if($destinasi != 'data not found')
	    {
	        echo "<option>- Pilih Destinasi -</option>";
	        foreach($destinasi as $row)
	        {
	        echo "<option value='".$row['id_destinasi']."'>".$row['nama_destinasi']."</option>";
	        }
	    }
	    else{
	        echo "<option>- Data Belum Tersedia -</option>";
	    }
	    ?>
	</select>
