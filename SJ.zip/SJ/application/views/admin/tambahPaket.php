<div class="container halaman-tambah-paket">
	<div class="paket-info">
		<h2>Tambah Paket</h2>
	</div>
	<div class="form-catatan">
		<p>Isi form di bawah ini untuk membuat paket perjalanan wisata yang baru</p>
		<p>*semua field form harus diisi</p>
	</div>
	<?php
		$infoWarning = $this->session->flashdata('infoWarning');
		if (!empty($infoWarning)) {
			echo '
			<div class="alert alert-danger" role="alert">
				'.$infoWarning.'
			</div>
			';
		}

	?>
	<!--
	<select id="mark" name="mark">
	  <option value="">--</option>
	  <option value="bmw">BMW</option>
	  <option value="audi">Audi</option>
	</select>
	<select id="series" name="series">
	  <option value="">--</option>
	  <option value="series-3" class="bmw">3 series</option>
	  <option value="series-5" class="bmw">5 series</option>
	  <option value="series-6" class="bmw">6 series</option>
	  <option value="a3" class="audi">A3</option>
	  <option value="a4" class="audi">A4</option>
	  <option value="a5" class="audi">A5</option>
	</select>
	-->
	<div class="form-tambah-paket">
		<form role="form" method="POST" action="<?php echo site_url(); ?>/paket" enctype="multipart/form-data">
			<div class="pilihan destinasi">
				<label>
					<h3>Pilihan Destinasi</h3>
				</label>
				<div class="form-group"> 
					<label>
						Destinasi 1
					</label>
					<div>
					<!--
						<div id="pilih-agama">
	          				<label>Pilihan agama : </label>
	          				<select name="agama" id="agama">
	          					<?php /*
	          					echo '<option>- Pilih Agama -</option>';
	          					foreach ($agama as $row) { //ambil data dari modelDestinasi untuk agama
	          						echo '<option value="'.$row['agama'].'">'.$row['agama'].'</option>';
	          					}*/
	          					?>
	          				</select>
          				</div>  
          				-->
	          			<div id="pilih-destinasi">
	          				<label>Pilihan destinasi : </label>
	          				<select name="destinasi-1" id="destinasi">
	          					<?php 
	          					echo '<option>- Pilih Destinasi -</option>';
	          					foreach ($destinasi as $row) { 
	          						echo '<option value="'.$row['id_destinasi'].'" class="'.$row['agama'].'">
	          						'.$row['nama_destinasi'].'</option>';
	          					}
	          					?>
	          				</select>
					    </div>
	    <script type="text/javascript"> 
$("#series").chained("#mark");
/*
$("#destinasi").remoteChained({
    parents : "#agama",
    url : "<?php echo site_url(); ?>/admin/getJsonDestinasi"
});
	    
$(function(){
               alert('msg'); 
	    $("#destinasi").chained("#agama");
        $("#agama").change(function(){
                var pilih-agama = {pilih-agama:$("#agama").val()};
                   $.ajax({
               type: "POST",
               url : "<?php echo site_url(); ?>/admin/getPilihDestinasi",
               data: pilih-agama,
               success: function(msg){
               $('#destinasi').html(msg);
               }
            });
              });
    }); */
       </script>
				    </div>
				</div>
				<!-- Destinasi 2 -->
				<div class="form-group"> 
					<label>
						Destinasi 2
					</label>
					<div>
						<div id="pilih-destinasi">
	          				<label>Pilihan destinasi : </label>
	          				<select name="destinasi-2" id="destinasi">
	          					<?php 
	          					echo '<option>- Pilih Destinasi -</option>';
	          					foreach ($destinasi as $row) { 
	          						echo '<option value="'.$row['id_destinasi'].'" class="'.$row['agama'].'">
	          						'.$row['nama_destinasi'].'</option>';
	          					}
	          					?>
	          				</select>
					    </div>
					</div>
				</div>
				<!-- Destinasi 3 -->
				<div class="form-group"> 
					<label>
						Destinasi 3
					</label>
					<div>
						<div id="pilih-destinasi">
	          				<label>Pilihan destinasi : </label>
	          				<select name="destinasi-3" id="destinasi">
	          					<?php 
	          					echo '<option>- Pilih Destinasi -</option>';
	          					foreach ($destinasi as $row) { 
	          						echo '<option value="'.$row['id_destinasi'].'" class="'.$row['agama'].'">
	          						'.$row['nama_destinasi'].'</option>';
	          					}
	          					?>
	          				</select>
					    </div>
					</div>
				</div>
				<!-- Destinasi 4 -->
				<div class="form-group"> 
					<label>
						Destinasi 4
					</label>
					<div>
						<div id="pilih-destinasi">
	          				<label>Pilihan destinasi : </label>
	          				<select name="destinasi-4" id="destinasi">
	          					<?php 
	          					echo '<option>- Pilih Destinasi -</option>';
	          					foreach ($destinasi as $row) { 
	          						echo '<option value="'.$row['id_destinasi'].'" class="'.$row['agama'].'">
	          						'.$row['nama_destinasi'].'</option>';
	          					}
	          					?>
	          				</select>
					    </div>
					</div>
				</div>
				<!-- Destinasi 5 -->
				<div class="form-group"> 
					<label>
						Destinasi 5
					</label>
					<div>
						<div id="pilih-destinasi">
	          				<label>Pilihan destinasi : </label>
	          				<select name="destinasi-5" id="destinasi">
	          					<?php 
	          					echo '<option>- Pilih Destinasi -</option>';
	          					foreach ($destinasi as $row) { 
	          						echo '<option value="'.$row['id_destinasi'].'" class="'.$row['agama'].'">
	          						'.$row['nama_destinasi'].'</option>';
	          					}
	          					?>
	          				</select>
					    </div>
					</div>
				</div>
			</div>
			<div class="form-group"> 
				<label>
					Nama Paket
				</label>
				<input required type="text" class="form-control" name="namaPaket" />
			</div>
			<div class="form-group"> 
				<label>
					Harga Paket
				</label>
				<input required type="text" class="form-control" name="harga" />
			</div>
			<div class="form-group"> 
				<label>
					Lama Perjalanan
				</label>
				<div>
				<select required name="waktu" >
					<option value="1">1 Hari</option>
					<option value="2">2 Hari</option>
					<option value="3">3 Hari</option>
					<option value="4">4 Hari</option>
					<option value="5">5 Hari</option>
				</select>
				</div>
			</div>
			<div class="form-group"> 
				<label>
					Kategori Paket
				</label>
				<div>
				<select required name="agama" >
					<option value="islam">Islam</option>
					<option value="kristen">Kristen</option>
					<option value="budha">Budha</option>
					<option value="hindu">Hindu</option>
				</select>
				</div>
			</div>
			<div class="form-group"> 
				<label>
					Informasi Paket
				</label> <br>
				<textarea required class="input-info" name="infoPaket"></textarea>
			</div>
			<button type="submit" class="btn btn-default">
				Tambah Paket
			</button>
		</form>
	</div>		
</div>	