<?php
	$infoWarning = $this->session->flashdata('infoWarning');
	if (!empty($infoWarning)) {
		echo '
		<div class="alert alert-danger" role="alert">
			'.$infoWarning.'
		</div>
		';
	}

?>
<div class="container halaman-tambah-paket">
	<div class="paket-info">
		<h2>Edit Paket</h2>
	</div>
	<div class="form-catatan">
		<p>Isi form di bawah ini untuk mengedit paket perjalanan wisata yang baru</p>
		<p>*Semua field form harus diisi</p>
		<p>*Pilihan destinasi paket tidak dapat diubah</p>
	</div>
	<?php 
	foreach ($paket as $paket) { ?>
	<div class="form-tambah-paket">
		<form role="form" method="POST" action="<?php echo site_url(); ?>/paket/editPaket" enctype="multipart/form-data">
			<input required type="hidden" class="form-control" name="idPaket" value="<?php echo $paket['id_paket']; ?>" />
			<div class="form-group"> 
				<label>
					Nama Paket
				</label>
				<input required type="text" class="form-control" name="namaPaket" value="<?php echo $paket['nama_paket']; ?>" />
			</div>
			<div class="pilihan destinasi">
				<label>
					<h3>Pilihan Destinasi</h3>
				</label>
				<input required type="hidden" class="form-control" name="idPilihanDestinasi" value="<?php echo $paket['id_pilihan_destinasi']; ?>" />
				<ol>
					<li><?php echo $paket['destinasi1']; ?></li>
					<li><?php echo $paket['destinasi2']; ?></li>
					<li><?php echo $paket['destinasi3']; ?></li>
					<li><?php echo $paket['destinasi4']; ?></li>
					<li><?php echo $paket['destinasi5']; ?></li>
				</ol>
			</div>
			<div class="form-group"> 
				<label>
					Harga Paket
				</label>
				<input required type="text" class="form-control" name="harga" value="<?php echo $paket['harga_paket']; ?>" />
			</div>
			<div class="form-group"> 
				<label>
					Lama Perjalanan
				</label>
				<div>
				<select required name="waktu" >
					<option value="<?php echo $paket['waktu']; ?>" selected=""><?php echo $paket['waktu']; ?> Hari</option>
					<option value="1">1 Hari</option>
					<option value="2">2 Hari</option>
					<option value="3">3 Hari</option>
					<option value="4">4 Hari</option>
					<option value="5">5 Hari</option>
				</select>
				</div>
			</div>
			<div class="form-group"> 
				<label>
					Kategori Paket
				</label>
				<div>
				<select required name="kategori" >
					<option value="<?php echo $paket['agama']; ?>" selected=""><?php echo $paket['agama']; ?></option>
					<option value="islam">Islam</option>
					<option value="kristen">Kristen</option>
					<option value="budha">Budha</option>
					<option value="hindu">Hindu</option>
				</select>
				</div>
			</div>
			<div class="form-group"> 
				<label>
					Informasi Paket
				</label> <br>
				<textarea required class="input-info" name="infoPaket"><?php echo $paket['info_paket']; ?></textarea>
			</div>
			<div class="form-group"> 
				<label>
					File foto
				</label>
				<input required type="file" accept="image/jpeg" name="fotoPaket" />
				<p class="help-block">
					Masukan file foto paket yang ditambahkan
				</p>
			</div>
			<button type="submit" class="btn btn-default">
				Edit Paket
			</button>
		</form>
	</div> <?php
	} ?>
</div>