<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Spiritual Journey</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- bootstrap-css -->
<link href="<?php echo base_url(); ?>css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- //bootstrap-css -->
<!-- css -->
<link href="<?php echo base_url(); ?>css/style.css" rel='stylesheet' type='text/css' />
<link href="<?php echo base_url(); ?>css/lightbox.css" rel="stylesheet" >
<!-- //css -->
<!-- fonts -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300italic,700' rel='stylesheet' type='text/css'>
<!-- //fonts -->
<script src="<?php echo base_url(); ?>js/jquery-1.11.1.min.js"> </script>	
<script src="<?php echo base_url(); ?>js/bootstrap.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>	
<!--pop-up-->
<script src="<?php echo base_url(); ?>js/menu_jquery.js"></script>
<!--//pop-up-->	
		<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
		<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.chained.min.js"></script>
		<script src="<?php echo base_url(); ?>jquery.chained.remote.min.js"></script>

</head>

<body>
	<!-- header -->
	<div class="header">
		<!-- container -->
		<div class="container">
			<div class="header-bottom">
				<div class="logo">
					<h1><a href="<?php echo site_url().$control; ?>">
					<img class="logo-sj" src="<?php echo base_url(); ?>/images/SJ1.png"> Spiritual Journey</a></h1>
				</div>
				<div class="clearfix"> </div>
			</div>

			<!-- top nav -->
			<?php $this->load->view('nav'); ?>
			<!-- //top nav -->

		</div>
		<!-- //container -->
	</div>
	<!-- //header -->
	
	<!-- content -->
	<?php $this->load->view($content); ?>
	<!-- //content -->
	
	<!-- footer -->
	<?php $this->load->view('footer'); ?>
	<!-- //footer -->

	<script type="text/javascript">
									$(document).ready(function() {
										/*
										var defaults = {
								  			containerID: 'toTop', // fading element id
											containerHoverID: 'toTopHover', // fading element hover id
											scrollSpeed: 1200,
											easingType: 'linear' 
								 		};
										*/
										
										$().UItoTop({ easingType: 'easeOutQuart' });
										
									});
								</script>
									<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	<!-- content-Get-in-touch -->
	<script type="text/javascript" src="<?php echo base_url(); ?>js/move-top.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>js/easing.js"></script>
</body>
</html>