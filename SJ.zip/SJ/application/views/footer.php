<div class="footer">
		<!-- container -->
		<div class="container">
			<div class="copyright">
				<p>© 2015 <img src="<?php echo base_url(); ?>/images/SJ-footer.png" height="50px" width="100px">. All rights reserved </p>
			</div>
		</div>
		<!-- //container -->
	</div>