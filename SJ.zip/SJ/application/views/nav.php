<div class="top-nav">
				<nav class="navbar navbar-default">
					<div class="container">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">Menu						
						</button>
					</div>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav">
							<li class="home-icon"><a href="index.html"><span class="glyphicon glyphicon-home" aria-hidden="true"></span></a></li>
							<li><a href="<?php echo site_url().$control; ?>">Home</a></li>
							<li><a href="<?php echo site_url().$control; ?>/daftarPaket">Daftar Paket</a></li>
							<li><a href="<?php echo site_url().$control; ?>/gallery">Galeri</a></li>
							<?php $this->load->view($nav); ?>
						</ul>	
						<div class="clearfix"> </div>
					</div>	
				</nav>	
			</div>