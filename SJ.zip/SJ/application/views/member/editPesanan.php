<div class="container halaman-form-pemesanan">
	<div class="paket-info">
		<h2>Edit Pemesanan</h2>
	</div>
	<div class="form-catatan">
		<p>Isi form di bawah ini untuk mengedit pemesanan paket perjalanan wisata kami</p>
		<p>*semua field form harus diisi</p>
	</div>
	<div class="form-pemesanan">
			<form role="form">
				<div class="form-group"> 
					<label>
						Nama Paket
					</label>
					<input required disabled="" readonly="" type="text" class="form-control" name="namaPaket" value="kkkk" />
					*data tidak dapat diubah
				</div>
				<div class="form-group">
					<label>
						Harga Paket
					</label>
					<input required disabled="" readonly="" type="text" class="form-control" name="harga" value="kkkk"/>
					*data tidak dapat diubah
				</div>
				<div class="form-group"> 
					<label>
						Lama Perjalanan
					</label>
					<input required disabled="" readonly="" type="text" class="form-control" name="waktu" value="kkkk"/>
					*data tidak dapat diubah
				</div>
				<div class="form-group"> 
					<label>
						Nama Pemesan
					</label>
					<input required type="text" class="form-control" name="namaPemesan" />
				</div>
				<div class="form-group"> 
					<label>
						Email
					</label>
					<input required type="email" class="form-control" name="email" />
				</div>
				<div class="form-group"> 
					<label>
						Nomor Telepon 
					</label>
					<input required type="tel" class="form-control" name="telepon" />
				</div>
				<div class="form-group"> 
					<label>
						Provinsi
					</label>
					<input required type="text" class="form-control" name="provinsi" />
				</div>
				<div class="form-group"> 
					<label>
						Kota
					</label>
					<input required type="text" class="form-control" name="kota" />
				</div>
				<div class="form-group"> 
					<label>
						Alamat Pemesan
					</label> <br>
					<textarea required class="input-alamat" name="alamat"></textarea>
				</div>
				<div class="form-group"> 
					<label>
						Tanggal Keberangkatan
					</label>
					<input required type="date" class="form-control" name="tanggalBerangkat" />
				</div>
				<div class="form-group"> 
					<label>
						Jumlah Wisatawan
					</label>
					<input required type="text" class="form-control" name="jumlahWisatawan" />
				</div>
				<div class="form-group">
					<table class="table-form-wisatawan">
						<thead>
							<th width="50px">No.</th>
							<th width="460px">Nama Wisatawan</th>
							<th width="460px">Nomor Pengenal *(KTP, SIM, KTM)</th>
						</thead>
						<tbody>
							<td>1</td>
							<td><input required type="text" class="form-wisatawan" name="namaWisatawan" /></td>
							<td><input required type="text" class="form-wisatawan" name="nomorPengenal" /></td>
						</tbody>
					</table>
				</div>
				<div class="form-group">
					<div class="checkbox">			 
							<label>
								<input type="checkbox" /> Dengan ini saya memenuhi persayaratan dan ketentuan pemesanan 
								paket perjalanan wisata.
							</label>
					</div>
				</div>									
				<button type="submit" class="btn btn-default">
					Submit
				</button>
			</form>
	</div>
</div>