<div class="container">
	<div class="row clearfix">
		<div class="col-md-12 column">
		<br><br>
			<div class="tabbable" id="tabs-72991">
				<ul class="nav nav-tabs">
					<li class="active">
						<a href="#panel-daftar-pesanan" data-toggle="tab">Pesanan Paket</a>
					</li>
				</ul>
				<div class="tab-content">
					<div class="tab-pane active" id="panel-daftar-pesanan">
						<div class="paket-info">
							<h2>Daftar Pemesanan</h2>
						</div>
<?php
	$infoSuccess = $this->session->flashdata('infoSuccess');
	if (!empty($infoSuccess)) {
		echo '
		<div class="alert alert-success" role="alert">
			'.$infoSuccess.'
		</div>
		';
	}

	$infoWarning = $this->session->flashdata('infoWarning');
	if (!empty($infoWarning)) {
		echo '
		<div class="alert alert-danger" role="alert">
			'.$infoWarning.'
		</div>
		';
	}

?>
						<div class="list-pemesanan">
						<table class="table">
							<thead>
								<tr>
									<th>No</th>
									<th>Nama Paket</th>
									<th>Nama Pemesan</th>
									<th>Harga Paket</th>
									<th>Lama Perjalanan</th>
									<th>Tanggal Keberangkatan</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
						<?php 	
						$nomor = 1;
						foreach ($pemesanan as $pemesanan) { ?>
								<tr>
									<td><?php echo $nomor; ?></td>
									<td><?php echo $pemesanan['nama_paket']; ?></td>
									<td><?php echo $pemesanan['nama_pemesan']; ?></td>
									<td><?php echo $pemesanan['harga_paket']; ?></td>
									<td><?php echo $pemesanan['waktu']; ?> hari</td>
									<td><?php echo $pemesanan['tanggal_berangkat']; ?></td>
									<td>
										<a href="<?php echo site_url(); ?>/pemesanan/hapusPesanan/
										?id=<?php echo $pemesanan['id_pesan']; ?>&wisatawan=<?php echo $pemesanan['id_wisatawan']; ?>">
										<button type="submit" class="btn btn-default">Batal Pemesanan</button></a>
										<a href="<?php echo site_url(); ?>/member/halamanPesanan/?id=<?php echo $pemesanan['id_pesan']; ?>">
										<button type="submit" class="btn btn-default">Cek Pemesanan</button></a>
									</td>
								</tr>
								<?php	} ?>
							</tbody>
						</table>
						</div>
					</div>
<?php
	$infoSuccess = $this->session->flashdata('infoSuccessCostum');
	if (!empty($infoSuccessCos)) {
		echo '
		<div class="alert alert-success" role="alert">
			'.$infoSuccess.'
		</div>
		';
	}

	$infoWarning = $this->session->flashdata('infoWarningCostum');
	if (!empty($infoWarning)) {
		echo '
		<div class="alert alert-danger" role="alert">
			'.$infoWarning.'
		</div>
		';
	}

?>
					
				</div>
			</div>
			
		</div>
	</div>
</div>				