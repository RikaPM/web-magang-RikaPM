<div class="container halaman-form-pemesanan">
	<div class="paket-info">
		<h2>Form Pemesanan</h2>
	</div>
	<div class="form-catatan">
		<p>Isi form di bawah ini untuk memesan paket perjalanan wisata kami</p>
		<p>*semua field form harus diisi</p>
	</div>
	<div class="form-pemesanan">
		<form role="form" method="POST" action="<?php echo site_url(); ?>/pemesanan/buatPemesanan">
		<?php 
			foreach ($paket as $paket) { ?>
			<div class="form-group"> 
				<label>Nama Paket</label>
				<input required readonly type="hidden" class="form-control" name="idPaket" value="<?php echo $paket['id_paket']; ?>" />
				<input required readonly type="text" class="form-control" name="namaPaket" value="<?php echo $paket['nama_paket']; ?>" />
				*data tidak dapat diubah
			</div>
			<div class="form-group">
				<label>Harga Paket</label>
				<input required readonly type="text" class="form-control" name="hargaPaket" value="<?php echo $paket['harga_paket']; ?>"/>
				*data tidak dapat diubah
			</div>
			<div class="form-group"> 
				<label>Lama Perjalanan</label>
				<input required readonly type="text" class="form-control" name="waktu" value="<?php echo $paket['waktu']; ?>"/>
				*data tidak dapat diubah
			</div>
	<?php	} ?>
			<div class="form-group"> 
				<label>Nama Pemesan</label>
				<input required type="text" class="form-control" name="namaPemesan" />
			</div>
			<div class="form-group"> 
				<label>Email</label>
				<input required type="email" class="form-control" name="email" />
			</div>
			<div class="form-group"> 
				<label>Nomor Telepon</label>
				<input required type="tel" class="form-control" name="telepon" />
			</div>
			<div class="form-group"> 
				<label>Provinsi</label>
				<input required type="text" class="form-control" name="provinsi" />
			</div>
			<div class="form-group"> 
				<label>Kota</label>
				<input required type="text" class="form-control" name="kota" />
			</div>
			<div class="form-group"> 
				<label>Alamat Pemesan</label> <br>
				<textarea required class="input-alamat" name="alamat"></textarea>
			</div>
			<div class="form-group"> 
				<label>Tanggal Keberangkatan</label>
				<input required type="date" class="form-control" name="tanggalBerangkat" value="<?php echo $pemesanan['tanggal_berangkat']; ?>" />
			</div>
			<div class="form-group"> 
				<label>Jumlah Wisatawan</label>
				<input required readonly type="text" class="form-control" name="jumlahWisatawan" value="<?php echo $pemesanan['jumlah_wisatawan']; ?>"/>
			</div>
			<div class="form-group">
				<table class="table-form-wisatawan">
					<thead>
						<th width="50px">No.</th>
						<th width="460px">Nama Wisatawan</th>
					</thead>
					<tbody>
			<?php
					for ($i=1; $i <= $pemesanan['jumlah_wisatawan']; $i++) { ?>
					<tr>
						<td><?php echo $i; ?></td>
						<td><input required type="text" class="form-wisatawan" name="<?php echo 'wisatawan'.$i; ?>" /></td>
					</tr>
			<?php 		
					} ?>
					</tbody>
				</table>
			</div>
			<div class="form-group">
				<div class="checkbox">			 
					<label>
						<input type="checkbox" /> Dengan ini saya memenuhi persayaratan dan ketentuan pemesanan 
						paket perjalanan wisata.
					</label>
				</div>
			</div>									
			<button type="submit" class="btn btn-default">
				Submit
			</button>
		</form>
	</div>
</div>