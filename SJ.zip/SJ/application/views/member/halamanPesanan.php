<div class="container halaman-pesanan">
	<div class="row col-md-12">
		<div class="paket-info">
			<h2>Halaman Pemesanan</h2>
		</div>
<?php 	foreach ($pesanan as $pesanan) { ?>
		<div class="cek-pesanan">
		<table class="table-cek-pesanan">
			<tr>
				<td>Nama Paket</td>
				<td>:</td>
				<td><?php echo $pesanan['nama_paket'] ?></td>
			</tr>
			<tr>
				<td>Harga Paket</td>
				<td>:</td>
				<td><?php echo $pesanan['harga_paket'] ?></td>
			</tr>
			<tr>
				<td>Lama Perjalanan</td>
				<td>:</td>
				<td><?php echo $pesanan['waktu'] ?> hari</td>
			</tr>
			<tr>
				<td>Nama Pemesan</td>
				<td>:</td>
				<td><?php echo $pesanan['nama_pemesan'] ?></td>
			</tr>
			<tr>
				<td>Provinsi</td>
				<td>:</td>
				<td><?php echo $pesanan['provinsi'] ?></td>
			</tr>
			<tr>
				<td>Kota</td>
				<td>:</td>
				<td><?php echo $pesanan['kota'] ?></td>
			</tr>
			<tr>
				<td>Alamat</td>
				<td>:</td>
				<td><?php echo $pesanan['alamat_pemesan'] ?></td>
			</tr>
			<tr>
				<td>Telepon</td>
				<td>:</td>
				<td><?php echo $pesanan['nomor_telepon'] ?></td>
			</tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td><?php echo $pesanan['email'] ?></td>
			</tr>
			<tr>
				<td>Tanggal Berangkat</td>
				<td>:</td>
				<td><?php echo $pesanan['tanggal_berangkat'] ?></td>
			</tr>
			<tr>
				<td>Jumlah Wisatawan</td>
				<td>:</td>
				<td><?php echo $pesanan['jumlah_wisatawan'] ?></td>
			</tr>
			<tr>
				<td>Nama Wisatawan</td>
				<td>:</td>
				<td>
					<ul>
						<li><?php echo $pesanan['wisatawan1'] ?></li>
						<li><?php echo $pesanan['wisatawan2'] ?></li>
						<li><?php echo $pesanan['wisatawan3'] ?></li>
					</ul>
				</td>
			</tr>
		</table>
		</div>
<?php 	} ?>
	
	</div>
	
</div>