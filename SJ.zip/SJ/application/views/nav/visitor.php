<li><a href="<?php echo site_url().$control; ?>/registrasi">Registrasi Member</a></li>
<li class="login" float="left"><a href="<?php echo site_url().$control; ?>/login">Login</a>
</li>
<!--
<li><a href="<?php echo site_url().$control; ?>/registrasi">Registrasi Member</a></li>
<li class="login" float="left">
	<div id="loginContainer"><a href="#" id="loginButton"><span>Login</span></a>
		<div id="loginBox">
			<form id="loginForm" method="POST" action="<?php echo site_url(); ?>/login/logMember">
				<fieldset id="body">
					<fieldset>
						<label for="email">Username</label>
						<input required type="text" name="username">
					</fieldset>
					<fieldset>
						<label for="password">Password</label>
						<input required type="password" name="password" >
					</fieldset>
					<input  type="submit" id="login" value="Sign in">
				</fieldset>
	<div class="info-warning">
	<?php
		$info = $this->session->flashdata('infoWarning');
		if (!empty($info)) {
			echo $info;
		}
	?>
	</div>
			</form>
		</div>
	</div>
</li>
-->