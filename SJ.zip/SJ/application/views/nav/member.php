<li class="menu-member"><a href="#" class="dropdown-toggle hvr-bounce-to-bottom" data-toggle="dropdown" role="button" 
aria-haspopup="true" aria-expanded="false"><?php echo $data['username']; ?><span class="caret"></span></a>
	<ul class="dropdown-menu">
		<li><a class="hvr-bounce-to-bottom" href="<?php echo site_url().$control; ?>/daftarPesanan">Daftar Pemesanan</a></li>
		<li><a class="hvr-bounce-to-bottom" href="<?php echo site_url().$control; ?>/daftarPaket">Pemesanan Paket</a></li>
		<li class="divider"></li>
		<li><a class="hvr-bounce-to-bottom" href="<?php echo site_url(); ?>/logout">Logout</a></li>        
	</ul>
</li>