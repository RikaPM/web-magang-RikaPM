<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ControlVisitor extends CI_Controller {

	// fungsi pasti dilakukan ketika menjalankan controller controlVisitor langsung buat variabel yang diperlukan buat menampilkan halaman
	public function __construct()
	{
		parent::__construct();
		$this->isi = array(
			'nav' => 'nav/visitor',			// nav yang digunakan berdasarkan nav visitor
			'control' => '/controlVisitor'  // variabel controller untuk navigasi di nav dan dalam konten webnya 
		);
	}

	// fungsi index langsung menampilkan halaman home website
	public function index()
	{
		$isi = $this->isi;				
		$isi['content'] = 'home/home';
		$isi['foto'] = $this->modelDestinasi->getFoto();
		$this->load->view('index', $isi);
	}

	// untuk menampilkan galeri
	public function gallery()
	{
		$isi = $this->isi;
		$isi['foto'] = $this->modelDestinasi->getFoto();
		$isi['content'] = 'home/gallery';
		$this->load->view('index', $isi);
	}

	//menampilkan daftar paket
	public function daftarPaket()
	{
		$isi = $this->isi;
		$isi['content'] = 'home/daftarPaket';
		$isi['paket'] = $this->modelPaket->getListPaket();
		$this->load->view('index', $isi);
	}

	//menampilkan halaman paket
	public function halamanPaket()
	{
		$id = $_GET['id'];
		$isi = $this->isi;
		$isi['content'] = 'home/halamanPaket';
		$isi['paket'] = $this->modelPaket->getPaketDetail($id);
		$this->load->view('index', $isi);
	}

	//menampilkan halaman form registrasi
	public function registrasi()
	{
		$isi = $this->isi;
		$isi['content'] = 'home/registrasi';
		$this->load->view('index', $isi);
	}

	//menampilkan halaman login
	public function login()
	{
		$isi = $this->isi;
		$isi['content'] = 'home/login';
		$this->load->view('index', $isi);
	}

}
