<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Paket extends CI_Controller {

	// fungsi index akan langsung menampilkan halaman konfirmasi tambah paket

	public function index(){

		$isi['destinasi1'] = $this->modelDestinasi->getDestinasi($_POST['destinasi-1']);
		$isi['destinasi2'] = $this->modelDestinasi->getDestinasi($_POST['destinasi-2']);
		$isi['destinasi3'] = $this->modelDestinasi->getDestinasi($_POST['destinasi-3']);
		$isi['destinasi4'] = $this->modelDestinasi->getDestinasi($_POST['destinasi-4']);
		$isi['destinasi5'] = $this->modelDestinasi->getDestinasi($_POST['destinasi-5']);

		$paket = array(
			'nama_paket' 	=> $_POST['namaPaket'],
			'info_paket' 	=> $_POST['infoPaket'],
			'harga_paket' 	=> $_POST['harga'],
			'waktu' 		=> $_POST['waktu'],
			'agama' 		=> $_POST['agama']
		);

		$isi['nav'] = 'nav/admin';
		$isi['control'] = '/controlAdmin';
		$isi['content'] = 'admin/konfirmTambahPaket';
		$isi['paket'] = $paket;
		$isi['data'] = $this->session->userdata;
		$this->load->view('index', $isi);

	}

	// fungsi background yang akan 
	public function tambahPaket(){

		$target_path = "img-paket/";
		$target_path = $target_path.basename( $_FILES['fotoPaket']['name']);
		$target_path = str_replace(' ', '_', $target_path);
		echo $target_path.'<br>'.basename( $_FILES['fotoPaket']['name']);

		if(move_uploaded_file($_FILES['fotoPaket']['tmp_name'], $target_path)){
			$pilihanDestinasi = array(
				'id_destinasi1' 	=> $_POST['destinasi1'],
				'id_destinasi2'		=> $_POST['destinasi2'],
				'id_destinasi3' 	=> $_POST['destinasi3'],
				'id_destinasi4' 	=> $_POST['destinasi4'],
				'id_destinasi5' 	=> $_POST['destinasi5']
			);

			$pilihan_destinasi = $this->modelDestinasi->tambahPilihanDestinasi($pilihanDestinasi);
			foreach ($pilihan_destinasi as $row) {
				$id_pilihan_destinasi = $row['id_pilihan_destinasi'];
			}
		
			foreach ($pilihan_destinasi as $row) {
				$paket = array(
					'id_pilihan_destinasi' => $id_pilihan_destinasi,
					'nama_paket' 	=> $_POST['namaPaket'],
					'info_paket' 	=> nl2br($_POST['infoPaket']),
					'foto' 		 	=> $target_path,
					'harga_paket' 	=> $_POST['harga'],
					'waktu' 		=> $_POST['waktu'],
					'agama' 		=> $_POST['agama']
				);

				$this->modelPaket->addPaket($paket);
			}
		} else {
			$this->session->set_flashdata('infoWarning',"Maaf tidak dapat menambahkan paket");
			redirect('admin/tambahPaket');
		}
	}

	public function hapusPaket(){
		$paket['id_paket'] = $_GET['id'];
		$paket['id_pilihan_destinasi'] = $_GET['id_pilihan_destinasi'];
		//echo $paket['id_paket'].' dan '.$paket['id_pilihan_destinasi'];
		$this->modelPaket->deletePaket($paket); 
	}

	public function editPaket(){
		$target_path = "img-paket/";
		$target_path = $target_path.basename( $_FILES['fotoPaket']['name']);
		$target_path = str_replace(' ', '_', $target_path);
		// echo $target_path;
		
		if (move_uploaded_file($_FILES['fotoPaket']['tmp_name'], $target_path)) {
			$paket = array(
				'id_paket'		=> $_POST['idPaket'],
				'id_pilihan_destinasi' => $_POST['idPilihanDestinasi'],
				'nama_paket' 	=> $_POST['namaPaket'],
				'info_paket' 	=> nl2br($_POST['infoPaket']),
				'foto' 		 	=> $target_path,
				'harga_paket' 	=> $_POST['harga'],
				'waktu' 		=> $_POST['waktu'],
				'agama' 		=> $_POST['kategori']
			);
			echo $paket['id_paket'];
			$this->modelPaket->editPaket($paket);
		}
		else {
			$this->session->set_flashdata('infoWarning',"Maaf tidak dapat mengedit paket");
			redirect('admin/listPaket');
			echo "kosong";
		}
	}


}
