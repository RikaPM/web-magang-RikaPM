<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Destinasi extends CI_Controller {
	
	public function tambahDestinasi(){

		$target_path = "img-destinasi/";
		$target_path = $target_path.basename( $_FILES['fotoDestinasi']['name']);
		$target_path = str_replace(' ', '_', $target_path);
		echo $target_path.'<br>'.basename( $_FILES['fotoDestinasi']['name']);

		if(move_uploaded_file($_FILES['fotoDestinasi']['tmp_name'], $target_path)) {
	    	$foto = $target_path;
	    	$new_destinasi = array(
				'nama_destinasi' 	=> $_POST['nama'],
				'provinsi' 			=> $_POST['provinsi'],
				'kota' 				=> $_POST['kota'],
				'alamat' 			=> $_POST['alamat'],
				'agama' 			=> $_POST['agama'],
				'info_destinasi' 	=> nl2br($_POST['infoDestinasi']),
				'foto_destinasi' 	=> $foto
			);

			$this->modelDestinasi->addDestinasi($new_destinasi);
	    } else {
	    	$this->session->set_flashdata('infoWarning',"Maaf tidak dapat menambahkan destinasi baru karena file foto dudah ada dalam sistem.
	    		silahkan isi kembali form tambah destinasi");
	    	$this->load->view('admin/tambahDestinasi');
	    }		
	}

}
