<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->akses->getAksesMember();
		$this->isi = array(
			'nav' 		=> 'nav/member',
			'control' 	=> '/member',
			'data'		=> $this->session->userdata
		);
	}

	public function index()
	{
		$isi = $this->isi;
		$isi['foto'] = $this->modelDestinasi->getFoto();
		$isi['content'] = 'home/home';
		$this->load->view('index', $isi);
	}

	public function gallery()
	{
		$isi = $this->isi;
		$isi['foto'] = $this->modelDestinasi->getFoto();
		$isi['content'] = 'home/gallery';
		$this->load->view('index', $isi);
	}

	public function daftarPaket()
	{
		$isi = $this->isi;
		$isi['content'] = 'home/daftarPaket';
		$isi['paket'] = $this->modelPaket->getListPaket();
		$this->load->view('index', $isi);
	}

	public function halamanPaket()
	{
		$id = $_GET['id'];
		$isi = $this->isi;
		$isi['content'] = 'home/halamanPaket';
		$isi['paket'] = $this->modelPaket->getPaketDetail($id);
		$this->load->view('index', $isi);
	}

	public function daftarPesanan()
	{
		$isi = $this->isi;
		$isi['content'] = 'member/daftarPesanan';
		$id_member = $this->session->userdata['id_member'];
		$isi['pemesanan'] = $this->modelPemesanan->getListPemesanan($id_member);
		$this->load->view('index', $isi);
	}

	public function halamanPesanan()
	{
		$id_pesan = $_GET['id'];
		$isi = $this->isi;
		$isi['pesanan'] = $this->modelPemesanan->getPesanan($id_pesan);
		$isi['content'] = 'member/halamanPesanan';
		$this->load->view('index', $isi);
		/*foreach ($isi['pesanan'] as $pesanan) {
			echo $pesanan['nama_paket'];
		}*/
	}
	
	public function formPesanan()
	{
		$isi = $this->isi;
		$id = $_POST['idPaket'];
		$paket = $this->modelPaket->getPaket($id);
		$pemesanan = array(
			'tanggal_berangkat' => $_POST['tanggalBerangkat'],
			'jumlah_wisatawan' => $_POST['jumlahWisatawan']
		);
		$isi['paket'] = $paket;
		$isi['pemesanan'] = $pemesanan;
		$isi['content'] = 'member/formPemesanan';
		$this->load->view('index', $isi);
	}

	/*belum */
	public function PesanKostum()
	{
		$isi = $this->isi;
		$isi['content'] = 'member/formPemesanan';
		$this->load->view('index', $isi);
	}

	public function editPesanan()
	{
		$isi = $this->isi;
		$isi['content'] = 'member/editPesanan';
		$this->load->view('index', $isi);
	}

	/*belum */
	public function pilihPaket()
	{
		$isi = $this->isi;
		$isi['content'] = 'member/editPesanan';
		$this->load->view('index', $isi);
	}

}
