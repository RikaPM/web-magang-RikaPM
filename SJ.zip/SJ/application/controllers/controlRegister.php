<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ControlRegister extends CI_Controller {

	// fungsi index akan langsung menampilkan halaman konfirmasi registrasi

	public function index(){

		$new_member = array(
			'username' 	=> $_POST['username'],
			'password'	=> $_POST['password'],
			'nama' 		=> $_POST['nama'],
			'email' 	=> $_POST['email'],
			'provinsi' 	=> $_POST['provinsi'],
			'kota' 		=> $_POST['kota'],
			'alamat' 	=> $_POST['alamat'],
			'telepon' 	=> $_POST['telepon']
		);

		$isi['nav'] = 'nav/visitor';
		$isi['control'] = '/controlVisitor';
		$isi['content'] = 'home/konfirmRegistrasi';
		$isi['data'] = $new_member;
		$this->load->view('index', $isi);

	}

	// fungsi background yang akan 
	public function buatMember(){

		$new_member = array(
			'username' 	=> $_POST['username'],
			'password'	=> md5($_POST['password']),
			'nama' 		=> $_POST['nama'],
			'email' 	=> $_POST['email'],
			'provinsi' 	=> $_POST['provinsi'],
			'kota' 		=> $_POST['kota'],
			'alamat' 	=> $_POST['alamat'],
			'telepon' 	=> $_POST['telepon']
		);

		$this->modelMember->createMember($new_member);

	}


}
