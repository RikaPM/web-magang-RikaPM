<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->akses->getAksesAdmin();
		$this->isi = array(
			'nav' => 'nav/admin',
			'control' => '/admin',
			'data' => $this->session->userdata
		);
		$this->load->helper('html');
	}

	public function index()
	{
		$isi = $this->isi;
		$isi['foto'] = $this->modelDestinasi->getFoto();
		$isi['content'] = 'home/home';
		$this->load->view('index', $isi);
	}

	public function gallery()
	{
		$isi = $this->isi;
		$isi['foto'] = $this->modelDestinasi->getFoto();
		$isi['content'] = 'home/gallery';
		$this->load->view('index', $isi);
	}

	public function daftarPaket()
	{
		$isi = $this->isi;
		$isi['content'] = 'home/daftarPaket';
		$isi['paket'] = $this->modelPaket->getListPaket();
		$this->load->view('index', $isi);
	}

	public function registrasi()
	{
		$isi = $this->isi;
		$isi['content'] = 'home/registrasi';
		$this->load->view('index', $isi);
	}

	public function tambahDestinasi()
	{
		$isi = $this->isi;
		$isi['content'] = 'admin/tambahDestinasi';
		$this->load->view('index', $isi);
	}

	public function halamanPaket()
	{
		$id = $_GET['id'];
		$isi = $this->isi;
		$isi['content'] = 'home/halamanPaket';
		$isi['paket'] = $this->modelPaket->getPaketDetail($id);
		$this->load->view('index', $isi);
	}

	public function listPaket()
	{
		$isi = $this->isi;
		$isi['listPaket'] = $this->modelPaket->getListPaket();
		$isi['content'] = 'admin/listPaket';
		$this->load->view('index', $isi);
	}

	public function tambahPaket()
	{
		$isi = $this->isi;
		$isi['content'] = 'admin/tambahPaket';
		$isi['agama'] = $this->modelDestinasi->loadAgama();
		$isi['destinasi'] = $this->modelDestinasi->getListDestinasi();
		$this->load->view('index', $isi);
	}

	public function editPaket()
	{
		$isi = $this->isi;
		$isi['content'] = 'admin/editPaket';
		$id = $_GET['id'];
		$isi['paket'] = $this->modelPaket->getPaketDetail($id);
		$this->load->view('index', $isi);
	}

}
