<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pemesanan extends CI_Controller {

	// fungsi index akan langsung menampilkan halaman konfirmasi tambah paket

	public function buatPemesanan(){
		//$user = $this->session->userdata['id_member'];
		//echo $user;
		$wisatawan1 = $_POST['wisatawan1'];

		if (isset($_POST['wisatawan2'])) {
			$wisatawan2 = $_POST['wisatawan2'];
			if (isset($_POST['wisatawan3'])) {
				$wisatawan3 = $_POST['wisatawan3'];
			} else {
				$wisatawan3 = '-' ;
			}
		} else {
			$wisatawan2 = '-';
			$wisatawan3 = '-';
		}

		//echo $wisatawan1.'<br>'.$wisatawan2.'<br>'.$wisatawan3.'<br>';

		$wisatawan = array(
			'wisatawan1' => $wisatawan1,
			'wisatawan2' => $wisatawan2,
			'wisatawan3' => $wisatawan3 
		);
		
		
		$wisatawan = $this->modelPemesanan->addWisatawan($wisatawan);
		foreach ($wisatawan as $row) {
			$id_wisatawan = $row['id_wisatawan'];
		}

		//echo $id_wisatawan;
		
		$pemesanan = array(
			'id_paket' 			=> $_POST['idPaket'],
			'nama_pemesan' 		=> $_POST['namaPemesan'],
			'provinsi' 			=> $_POST['provinsi'],
			'kota' 				=> $_POST['kota'],
			'alamat_pemesan' 	=> $_POST['alamat'],
			'nomor_telepon'		=> $_POST['telepon'],
			'email'				=> $_POST['email'],
			'tanggal_berangkat'	=> $_POST['tanggalBerangkat'],
			'jumlah_wisatawan'	=> $_POST['jumlahWisatawan'],
			'id_wisatawan'		=> $id_wisatawan,
			'id_member'			=> $this->session->userdata['id_member']
		);

		$this->modelPemesanan->addPemesanan($pemesanan); 
	}

	public function hapusPesanan(){
		$pemesanan['id_pesan'] = $_GET['id'];
		$pemesanan['id_wisatawan'] = $_GET['wisatawan'];
		//echo $pemesanan['id_pesanan'].' dan '.$pemesanan['id_wisatawan'];
		$this->modelPemesanan->deletePesanan($pemesanan); 
	}

/*
	// fungsi background yang akan 
	public function tambahPaket(){

		$target_path = "img-paket/";
		$target_path = $target_path.basename( $_FILES['fotoPaket']['name']);
		$target_path = str_replace(' ', '_', $target_path);
		echo $target_path.'<br>'.basename( $_FILES['fotoPaket']['name']);

		if(move_uploaded_file($_FILES['fotoPaket']['tmp_name'], $target_path)){
			$pilihanDestinasi = array(
				'id_destinasi1' 	=> $_POST['destinasi1'],
				'id_destinasi2'		=> $_POST['destinasi2'],
				'id_destinasi3' 	=> $_POST['destinasi3'],
				'id_destinasi4' 	=> $_POST['destinasi4'],
				'id_destinasi5' 	=> $_POST['destinasi5']
			);

			$pilihan_destinasi = $this->modelDestinasi->tambahPilihanDestinasi($pilihanDestinasi);
			$id_pilihan_destinasi = $row['id_pilihan_destinasi'];
		
			foreach ($pilihan_destinasi as $row) {
				$paket = array(
					'id_pilihan_destinasi' => $id_pilihan_destinasi,
					'nama_paket' 	=> $_POST['namaPaket'],
					'info_paket' 	=> nl2br($_POST['infoPaket']),
					'foto' 		 	=> $target_path,
					'harga_paket' 	=> $_POST['harga'],
					'waktu' 		=> $_POST['waktu'],
					'agama' 		=> $_POST['agama']
				);

				$this->modelPaket->addPaket($paket);
			}
		} else {
			$this->session->set_flashdata('infoWarning',"Maaf tidak dapat menambahkan paket");
			redirect('admin/tambahPaket');
		}
	}

	public function hapusPaket(){
		$paket['id_paket'] = $_GET['id'];
		$paket['id_pilihan_destinasi'] = $_GET['id_pilihan_destinasi'];
		//echo $paket['id_paket'].' dan '.$paket['id_pilihan_destinasi'];
		$this->modelPaket->deletePaket($paket); 
	}

	public function editPaket(){
		$target_path = "img-paket/";
		$target_path = $target_path.basename( $_FILES['fotoPaket']['name']);
		$target_path = str_replace(' ', '_', $target_path);
		
		if (move_uploaded_file($_FILES['fotoPaket']['name'], $target_path)) {
				$paket = array(
				'id_paket'		=> $_POST['idPaket'],
				'id_pilihan_destinasi' => $_POST['idPilihanDestinasi'],
				'nama_paket' 	=> $_POST['namaPaket'],
				'info_paket' 	=> nl2br($_POST['infoPaket']),
				'foto' 		 	=> $target_path,
				'harga_paket' 	=> $_POST['harga'],
				'waktu' 		=> $_POST['waktu'],
				'agama' 		=> $_POST['kategori']
			);
			//echo $paket['id_paket'];
			$this->modelPaket->editPaket($paket);
		}
		else {
			$this->session->set_flashdata('infoWarning',"Maaf tidak dapat mengedit paket");
			redirect('admin/listPaket');
		}
	}
*/

}
