<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function logMember() {
		$username = $_POST['username'];
		$password = md5($_POST['password']);
		$data = $this->modelMember->login($username, $password);
	}

	public function logAdmin() {
		$username = $_POST['username'];
		$password = md5($_POST['password']);
		$data = $this->modelAdmin->login($username, $password);
	}


}