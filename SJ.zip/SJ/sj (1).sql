-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 21, 2015 at 09:51 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sj`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id_admin` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `level` int(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`, `level`) VALUES
(1, 'admin', '81dc9bdb52d04dc20036dbd8313ed055', 1);

-- --------------------------------------------------------

--
-- Table structure for table `destinasi`
--

CREATE TABLE IF NOT EXISTS `destinasi` (
  `id_destinasi` int(11) NOT NULL,
  `nama_destinasi` varchar(100) NOT NULL,
  `provinsi` varchar(50) NOT NULL,
  `kota` varchar(50) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `agama` varchar(10) NOT NULL,
  `info_destinasi` text NOT NULL,
  `foto_destinasi` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `destinasi`
--

INSERT INTO `destinasi` (`id_destinasi`, `nama_destinasi`, `provinsi`, `kota`, `alamat`, `agama`, `info_destinasi`, `foto_destinasi`) VALUES
(6, 'Goa Gajah', 'Bali', 'Desa Bedulu', 'Desa Bedulu, Kecamatan Blahbatuh, Kabupaten Gianya', 'budha', 'Berkunjung ke Goa Gajah merupakan suatu pengalaman yang sangat menarik. Selain menikmati keindahan dan suasananya yang sejuk dan damai, berwisata ke kawasan tempat suci ini juga memberikan nilai spiritual dan sejarah yang berharga.<br />\r\nAsal Nama Dari Pura Goa Gajah<br />\r\nKata “Goa Gajah” dipercaya berasal dari sebuah kata yang muncul di dalam kitab Negarakertagama. Diduga kata Goa Gajah berasal dari kata “ Lwa Gajah”, yang berarti wihara tempat pemujaan para Bhiksu umat beragama Budha. Pada lontar Negarakertagama yang disusun oleh Mpu Prapanca pada tahun 1365 M, terdapat nama tersebut. Sedangkan kata “ Lwa “ berarti sungai. Maka disimpulkan menjadi pertapaan yang terletak di tepi sungai.<br />\r\n', 'img-destinasi/goa-gajah_1.jpg'),
(7, 'Patung Budha Tidur di Vihara Dharma Giri Tabanan', 'Bali', 'Tabanan', 'Jalan Raya Pupuan, Tabanan, Provinsi Bali', 'budha', 'Belum banyak orang yang tahu tempat vihara ini, karena memang tujuan utama vihara ini dibangun adalah sebagai tempat peribadahan bagi umat budha. Namun bagi anda yang ingin datang hanya untuk sekadar melihat-lihat vihara ini masih diperbolehkan, asalkan anda dapat menjaga ketenangan karena vihara adalah sebuah tempat suci dan tempat umat budha melaksanakan semedi.<br />\r\n', 'img-destinasi/Budha_Tidur.jpg'),
(8, 'Candi Borobudur', 'Jawa Tengah', 'Magelang', 'Kecamatan Borobudur Kabupaten Magelang, Jawa Tenga', 'budha', 'Borobudur dibangun dalam era abad ke 8 dan pertengahan abad 9 pada masa emas wangsa sailendra<br />\r\nAda beberapa tahap pembangunan candi ini antara alain :<br />\r\nTahap Pembangunan Borobudur<br />\r\n* Tahap pertama<br />\r\nMasa pembangunan Borobudur tidak diketahui pasti (diperkirakan antara 750 dan 850 M). Pada awalnya dibangun tata susun bertingkat. Sepertinya dirancang sebagai piramida berundak. tetapi kemudian diubah. Sebagai bukti ada tata susun yang dibongkar.<br />\r\n* Tahap kedua<br />\r\nPondasi Borobudur diperlebar, ditambah dengan dua undak persegi dan satu undak lingkaran yang langsung diberikan stupa induk besar.<br />\r\n* Tahap ketiga<br />\r\nUndak atas lingkaran dengan stupa induk besar dibongkar dan dihilangkan dan diganti tiga undak lingkaran. Stupa-stupa dibangun pada puncak undak-undak ini dengan satu stupa besar di tengahnya.<br />\r\n* Tahap keempat<br />\r\nAda perubahan kecil seperti pembuatan relief perubahan tangga dan lengkung atas pintu.<br />\r\n', 'img-destinasi/Borobudur-Nothwest-view.jpg'),
(9, 'Watugong Semarang', 'Jawa Tengah', 'Semarang', 'Pudakpayung,Banyumanik,Kota Semarang, Jawa Tengah ', 'budha', 'Watugong adalah nama sebuah kawasan di tepi Selatan Kota Semarang. Namanya seunik ikon kawasan ini, yaitu sebuah batu berbentuk gong. Itulah sebabnya masyarakat setempat saat membina jalan raya di kawasan ini menyebutnya “watugong” atau batu seperti gong.<br />\r\nVihara ini sempat terlantar selama kurang lebih 8 tahun namun sekarang bangkit kembali di bawah binaan Sangha Theravada Indonesia. Keindahan menara vihara ditambah keunikan ornamen dan eksterior bangunannya telah menarik banyak para pelancong maupun peziarah untuk mendatanginya.<br />\r\nVihara Buddhagaya Watugong adalah sebuah Vihara yang diresmikan pada 2006 lalu dan dinyatakan MURI sebagai pagoda tertinggi di Indonesia. Pagoda ini dibangun tujuh tingkat dengan hampir semua konstruksi bangunannya terbuat dari beton, serta banyak menggunakan latar warna merah dan beberapa arca di tiap tingkat pagodanya. Vihara Buddhagaya Watugong terletak 45 menit dari pusat Kota Semarang. Vihara ini memiliki banyak bangunan dan berada di area yang luas dengan tinggi 45 m.<br />\r\n', 'img-destinasi/Watugong.jpg'),
(10, 'Brahmavihara-Arama', 'Bali', 'Banjar Tegeha', 'Banjar Tegeha, Kec. Buleleng, Bali 81152 ', 'budha', 'Brahmavihara-Aramamenyajikan suasana yang tenang dan sepi serta memungkinkan untuk emandang langsung ke Pantai Lovina yang jaraknya tak begitu jauh, membuat vihara umat Budha ini menjadi daya tarik yang impresif bagi siapapun yang mengunjunginya. Sebagaimana tempat ibadah umat-umat lainnya, Vihara ini juga memiliki beberapa bagian strategis yang diantaranya:<br />\r\n– Upostha Gara<br />\r\n– Stupa<br />\r\n– Dharmasala<br />\r\n– Kuti<br />\r\n', 'img-destinasi/Berwisata_Reliji_di_Brahmavihara-Arama_2.jpg'),
(11, 'Pura Luhur Giri Saloka Banyuwangi', 'Jawa Timur', 'Banyuwangi', 'Taman Nasional Alas Purwo,  Jl. Brawijaya No. 20, ', 'hindu', 'Alas purwo Bayuwangi menyajikan berbagai potensi wisata yang begitu menarik untuk dikunjungi, salah satu diantaranya adalah Pura Luhur Giri Seloka. Sebuah pura kuno bersejarah yang tersembunyi ditengah hutan dan hijau di alas purwo, meskipun letaknya ditengah hutan akan tetapi tempat tersebut selalu ramai dikunjungi oleh umat hindu di jawa dan bali.<br />\r\nPara peziarah umat hindu biasa datang ke Pura Luhur Giri Saloka saat merayakan hari raya pagerwesi, hari raya tersebut diperuntukan untuk menyucikan benda keramat dengan menggunakan air yang berasal dari 7 mata air yang berbeda. Pura tesebut sungguh disakralkan oleh masyarakat hindu disekitar wilayah alas purwo dan oleh orang hindu bali.<br />\r\nTidak hanya didatangi oleh umat hindu saja tetapi oleh wisatawan lainnya. Tempat pura tersebut bisa dijadikan wisata religi maupun wisata sejarah.<br />\r\n', 'img-destinasi/situs.giri_.salaka.alas_.purwo_.banyuwangi.jpg'),
(12, 'Pura Jaya Prana Bali', 'Bali', 'Buleleng', 'Sumber Klampok, Gerokgak, Buleleng, Bali 81155', 'hindu', 'Sudah pernahkah anda melihat sebuah film romantis antara Romeo dan Julliet? Ya, film tersebut menceritakan percintaan antara dua orang manusia. Jika anda ingin mengetahui lebih dalam, di Bali juga terdapat sebuah cerita percintaan antara Layon Sari dengan Jaya Prana. Dimana dalam cerita tersebut menggambarkan kesetiaan dari seorangLayon Sari terhadap kekasihnya yaitu Jaya Prana. Kisah tersebut dilambangkan dengan ukiran sepasang arca Jaya Prana dengan Layon Sari. Jika anda berkunjung ke Teluk Terima Bali, tidak ada salahnya untuk melihat-lihat sepasang arca yang melambangkan kuatnya kisah cinta antara Jaya Prana dengan Layon Sari', 'img-destinasi/pura-jayaprana.jpg'),
(14, 'Candi Prambanan Yogyakarta', 'Yogyakarta', 'Yogyakarta', 'Yogyakarta', 'hindu', 'Candi Prambanan (prambanan temple) merupakan salah satu obyek wisata di Yogyakarta yang sering dikunjungi oleh wisatawan baik lokal maupun mancanegara. Adalah bangunan candi yang luar biasa cantik yang dibangun pada abad kesepuluh masa pemerintahan dua raja, Rakai Pikatan dan Rakai Balitung. Menjulang setinggi 47 meter (5 meter lebih tinggi dari Candi Borobudur), berdirinya candi ini telah memenuhi keinginan pembuatnya, yaitu menunjukkan kejayaan Hindu di pulau Jawa. Merupakan candi yang harus dikunjungi ketika liburan ke Jogja setelah Borobudur.', 'img-destinasi/Candi-Prambanan-Yogyakarta-760x356.jpg'),
(15, 'Pura Rambut Siwi', 'Bali', 'Desa Yeh Embang Kangin', 'Desa Yeh Embang Kangin, Kecamatan Mendoyo, Jembran', 'hindu', 'Sebagai salah satu pura penting di Bali, Pura Rambut Siwi pun sering digunakan untuk acara keagamaan sesuai dengan kalender Hindu di Bali dan persembahyangan. Bagi umat Hindu sendiri, prosesi persembahyangan yang dianjurkan harus sesuai dengan urutan yang tepat, yaitu dimulai dari Pura Pesanggarahan (ada di pinggir jalan Denpasar-Gilimanuk) – Pura Taman (ada di sebelah timur jalan masuk ke Pura Rambut Siwi) – Pura Penataran (ada di sebelah timur Pura Rambut Siwi) – Pura Goa Tirta – Pura Melanting – Pura Gading Wani Pura Ratu Gede Dalem Ped – dan terakhir di Pura Luhur Rambut Siwi.<br />\r\nOh ya, ada satu kebiasaan unik yang bakalan kamu temukan saat berkunjung ke Pura Rambut Siwi. Kamu nggak usah heran ya kalau melihat banyak kendaraan dari berbagai arah yang tiba-tiba berhenti sejenak dan mampir ke pura, tepatnya di Pura Pesanggrahan yang menjadi salah satu bagian dari Pura Rambut Siwi. Ternyata, pengendara memang sengaja berhenti untuk berdoa dulu agar perjalanan yang sedang dilakukan lancar dan bisa selamat sampai tujuan. <br />\r\n', 'img-destinasi/rambut-siwi-e1442213036588.jpg'),
(16, 'PANTAI BALEKAMBANG', 'Jawa Timur', 'Kabupaten Malang', 'Dusun Sumber Jambe, Desa Srigonco, Kecamatan Bantu', 'hindu', 'Pura Luhur Amertha Jati termasuk pura yang megah. Sebuah jembatan penghubung pantai dengan pura dibangun diatas pantai untuk membantu pengunjung menuju pura. Dari atas jembatan ini anda bisa merasakan desir angin pantai yang juga menggoyang jembatan yang dulunya terbuat dari tali dan kayu. Namun kini jembatan tersebut telah diperbaiki sehingga lebih kokoh dan tentunya lebih aman bagi pengunjung. Karena keberadaan Pura Luhur Amertha Jati ini pula menjadikan Pulau Ismoyo termasuk kawasan suci dimana terdapat sejumlah aturan untuk memasukinya, sebagaimana layaknya pura yang ada di Bali. Salah satunya adalah larangan bagi wanita yang datang bulan untuk bertandang. Jika larangan ini dilanggar, kabarnya si wanita akan dimasuki penunggu pura.', 'img-destinasi/beach-bale-kambang-2-300x225.jpg'),
(17, 'Tanah Lot Bali', 'Bali', 'Kab.Tabanan Bali', 'Desa Beraba Kecamatan Kediri Kab.Tabanan Bali', 'hindu', 'Pariwisata Indonesia – Tanah Lot merupakan tempat wisata yang ada di Bali. Di kawasan ini terdapat dua buah pura yang terletak di atas batu besar, salah satunya terletak di atas bongkahan batu, jika air laut pasang maka pura ini akan terlihat di kelilingi air laut. Sedangkan yang satunya lagi tepat berada di sebelah utara Pura Tanah Lot dengan posisi di atas tebing dan sedikit menjorok ke laut yang mirip dengan Pura Uluwatu. Pura Tanah Lot yang berada terpisah dari daratan ini dapat di jangkau tanpa menggunakan perahu apabila pada saat air laut pasang surut. Pura yang lebih di kenal dengan Sad Kahyangan ini adalah salah satu pura utama yang ada di Pulau Bali.', 'img-destinasi/Tanah-Lot6-e1308482975761.jpg'),
(18, 'Makam Sunan Ampel', 'Jawa Timur', 'Surabaya', 'Jalan Pertukangan I, Surabaya, Jawa Timur', 'islam', 'Bagi peziarah atau peminat wisata religi maka kawasan Sunan Ampel sangatlah dikenal. Masjid ini adalah masjid yang paling terkenal dan suci bagi umat Muslim di Surabaya, setelah Masjid Akbar Surabaya. Tepat di belakang Masjid Ampel terdapat kompleks makam Sunan Ampel yang meninggal pada 1481. Di kawasan ini ada yang menarik yaitu keberadaan Kampung Arab yang sebagian besar ditempati keturunan Arab Yaman dan Cina yang sudah menetap ratusan tahun untuk berdagang. Suasana kehidupan para pedagang ini nyaris seperti suasana di Makkah.', 'img-destinasi/Makam_Sunan_Ampel_dengan_Masjid_barunya..jpg'),
(19, 'Makam Sunan Giri', 'Jawa Timur', 'Gresik', 'Jalan Sunan Giri No. 18, Gresik, Jawa Timur 61121', 'islam', 'Sunan Giri dikenal sebagai salah satu Wali Songo dan juga pendiri dinasti Giri Kedaton. Selain itu, Makam Sunan Giri juga lebih dekat dengan masjid, yaitu Masjid Sunan Giri. Sunan Giri adalah putera Maulana Ishaq (anak Syekh Jumadil Qubro) dengan Dewi Sekardadu, putri Prabu Menak Sembuyu, penguasa Blambangan. Syekh Jumadil Qubro datang dari Samarkand ke Pulau Jawa bersama kedua anaknya, yaitu Maulana Malik Ibrahim (Sunan Gresik) dan Maulana Ishaq. Adalah Maulana Ishaq yang mengislamkan Pasai dan tinggal di sana. Bagian luar Makam Sunan Giri dengan ornamen bentuk-bentuk lengkung simetris dan repetitif pada fondasi batuan putihnya, serta dinding gebyog kayu dengan ornamen ukiran yang rumit dan indah. Sebuah karya seni budaya Jawa untuk menunjukkan penghormatan dan kecintaan masyarakat kepada sang penghuni makam.', 'img-destinasi/makam-sunan-giri-5.jpg'),
(20, 'Masjid Tiban Turen', 'Jawa Timur', 'Kabupaten Malang', 'Pondok pesantren Biharu Bahri’Asali Fadlaailir Rah', 'islam', 'Masjid Tiban, demikian masyarakat menyebutnya. Sebuah masjid besar yang penuh dengan keagungan dan keindahan. Masjid Tiiban merupakan sebuah masjid yang terletak didaerah Turen Kabupaten Malang, tepatnya berada diarea pondok pesantren Biharu Bahri’Asali Fadlaailir Rahmah Jl.Anggur Rt 27 Rw 06 Sananrejo Kecamatan Turen Kabupaten Malang. Masjid ini disebut ini disebut sebagai Masjid Tiban dikarenakan anggapan masyarakat yang sekitar yang mengisukan bahwa masjid ini tiba-tiba ada. <br />\r\n 	Hal inilah yang mungkin menjadikan banyak orang yang penasaran untuk melihat dan membuktikan keberadaan masjid ini. Sehingga tak heran jika diarea masjid ini dapat anda temui banyak orang yang datang untuk berwisata sembari mengobati rasa penasaran mereka akan asal usul masjid ini. <br />\r\n 	Masjid ini sendiri mulai dibangun pada pada tahun 1991 dan sampai saat ini pembangunan Masjid Tiban ini belum bisa dikatakan rampung. Namun hal yang menarik yang perlu Anda ketahui dibalik pembanguna kompleks masjid tiban ini adalah tentang tidak adanya perencaan. Hal ini dikarenakan karena pembangunan masjid yang meliputi bentuk bangunan dan segala ornamen yang ada didalamnya merupakan petunjuk dari sang Kholiq, malalui sholat istiqoroh yang dilakukan oleh Romo Yai di Masjid itu. Ini kami dapatkan ketika kami berbincang dengan salah satu pekerja lapangan yang sudah cukup lama bekerja disana.<br />\r\n', 'img-destinasi/masjid_tiban_turen.jpg'),
(21, 'Kampung Islam Pulau Serangan', 'Bali', 'Bali', 'Pulau Serangan Bali Selatan', 'islam', 'Di Pulau Serangan, sebuah sebuah pulau kecil yang terletak di sebelah selatan Kota Denpasar, yang kini telah direklamasi menjadi satu dengan Pulau Bali, terdapat sebuah kampung yang dihuni sekitar 60 kepala keluarga yang menganut agama Islam yang berasal dari Suku Bugis. Kampung tersebut dikenal dengan Kampung Bugis.<br />\r\nDi Kampung Bugis inilah, terdapat sebuah masjid dan Al Qur''an kuno yang diperkirakan dari abad ke-17 Masehi. Masjid tersebut merupakan satu-satunya di Pulau Serangan dan diberi nama Assyuhada. Meski sudah mengalami beberapa kali renovasi, namun bentuk dan corak arsitektur masjid masih kental terlihat. Bahkan mimbar khotbah dan jendela masjid masih asli.<br />\r\nSelain peninggalan masjid, warga kampung Bugis di Pulau Serangan juga mewarisi sebuah kitab suci Al-Qur''an yang juga diperkirakan dari abad ke-17 Masehi. Al-Qur''an Kuno tersbeut ditulis tangan dan pada bagian sampulnya terbuat dari kulit unta.<br />\r\n', 'img-destinasi/Alquran_kuno_Kampung_serangan.jpg'),
(22, 'Wisata Wali Tujuh Bali', 'Bali', 'Bali', 'Pulau Bali', 'islam', 'Sejarah Wali Pitu di Bali<br />\r\nMakam diatas bukit Bedugul yang keluarganya kunjungi itu merupakan salah satu makam dari Wali Pitu atau Wali Tujuh di Bali.  Mengutip buku Perjuangan Wali Pitu dan Wali Enam di Bali, Wali Pitu sendiri merupakan tokoh penyebar agama Islam d Pulau Bali. Nama Wali Pitu mulai dikenal sekitar tahun 1990-an.<br />\r\n<br />\r\nWaktu itu ada seorang pemuka agama, Kiai Thoyyib Zen Arifin yang membukukan ke publik keberadaan Wali Pitu melalui penulisan buku yang berjudul Manaqib Wai Pitu di Bali dan Raja-raja Islam di Nusantara. Sedangkan objek Wali Pitu itu sendiri pertama diketemukan oleh KH Noor Hadi Pendiri sekaligus pengasuh Ponpes AlQuran Raudlotul Hufadz yang berlokasi di Kediri, Tabanan tahun 1979.<br />\r\n<br />\r\nPemberian gelar nama Wali Pitu dilakukan oleh dua orang ulama yang berasal dari pulau Jawa. Setelah melakukan pene,itian sebanyak tjuh makam selama beberapa tahun. Sebagian besar umat Islam di Bali dan Jawamenyetujui nama Wali Pitu. Meskipun jumlahnya yang dimakamnya lebih dari tujuh.<br />\r\n<br />\r\nWali Pitu di pulau Bali antara lain RA Siti Khotijah, Pengeran Mas Sepuh, Chatib Umar bin Yusuf Al Magribi, Habib Ali bin Abu Bakar, Syech Maulana Yusuf Al Baghdi Al Maghribi, Habib Ali Bin Zaenal Abidin dan Abdul Qodir Muhammad. Ketujuh makam wali yang menyebar di beberapa daerah di Bali ini hampir tiap hari mendapat kunjungan wisatawan dari kalangan muslim. Para peziarah kebanyakan berkunjung pada bulan Syawal atau Maulud.<br />\r\n', 'img-destinasi/Habib-Ali-Bin-Abu-Bakar-Bin-Umar-Bin-Abu-Bakar-Al-Khamid.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `id_member` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(32) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `provinsi` varchar(50) NOT NULL,
  `kota` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `telepon` int(12) NOT NULL,
  `level` int(2) NOT NULL DEFAULT '2'
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`id_member`, `username`, `password`, `nama`, `email`, `provinsi`, `kota`, `alamat`, `telepon`, `level`) VALUES
(14, 'lia', '81dc9bdb52d04dc20036dbd8313ed055', 'lia', 'lia@gmail.com', 'Jawa Timur', 'Malang', 'Jalan Veteran', 1234, 2),
(18, 'alia', '81dc9bdb52d04dc20036dbd8313ed055', 'alia', 'alia@gmail.com', 'Jawa Timur', 'Malang', 'Jalan Veteran', 1234, 2),
(19, 'test', '81dc9bdb52d04dc20036dbd8313ed055', 'tes1''', 'tets@mail.com', 'Jawa Timur', 'Malang', 'Malang', 1234, 2),
(23, 'test1', '81dc9bdb52d04dc20036dbd8313ed055', 'test1', 'test1@mail.com', 'Malang', 'Jawa Timur', 'Malang', 1234, 2);

-- --------------------------------------------------------

--
-- Table structure for table `paket`
--

CREATE TABLE IF NOT EXISTS `paket` (
  `id_paket` int(11) NOT NULL,
  `id_pilihan_destinasi` int(11) NOT NULL,
  `nama_paket` varchar(50) NOT NULL,
  `info_paket` text NOT NULL,
  `foto` varchar(100) NOT NULL,
  `harga_paket` double NOT NULL,
  `waktu` int(11) NOT NULL,
  `agama` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paket`
--

INSERT INTO `paket` (`id_paket`, `id_pilihan_destinasi`, `nama_paket`, `info_paket`, `foto`, `harga_paket`, `waktu`, `agama`) VALUES
(1, 35, 'Paket Agama Budha', 'info paket agama Budha', 'img-paket/Borobudur-Nothwest-view.jpg', 500000, 3, 'budha'),
(2, 36, 'Paket Agama Hindu', 'Informasi Paket Hindu', 'img-paket/Candi-Prambanan-Yogyakarta-760x356.jpg', 500000, 5, 'hindu'),
(3, 37, 'Paket Agama Islam', 'Informais Paket Agama Islam', 'img-paket/masjid_tiban_turen.jpg', 420000, 4, 'islam');

-- --------------------------------------------------------

--
-- Table structure for table `pemesanan`
--

CREATE TABLE IF NOT EXISTS `pemesanan` (
  `id_pesan` int(10) NOT NULL,
  `id_paket` int(10) NOT NULL,
  `nama_pemesan` varchar(20) NOT NULL,
  `provinsi` varchar(20) NOT NULL,
  `kota` varchar(20) NOT NULL,
  `alamat_pemesan` varchar(50) NOT NULL,
  `nomor_telepon` int(12) NOT NULL,
  `email` varchar(20) NOT NULL,
  `tanggal_berangkat` date NOT NULL,
  `jumlah_wisatawan` int(3) NOT NULL,
  `id_wisatawan` int(11) NOT NULL,
  `id_member` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pemesanan`
--

INSERT INTO `pemesanan` (`id_pesan`, `id_paket`, `nama_pemesan`, `provinsi`, `kota`, `alamat_pemesan`, `nomor_telepon`, `email`, `tanggal_berangkat`, `jumlah_wisatawan`, `id_wisatawan`, `id_member`) VALUES
(1, 1, 'alia', 'Jawa Timur', 'Malang', '1234', 1234, 'alia@mail.com', '2015-12-10', 2, 15, 18);

-- --------------------------------------------------------

--
-- Table structure for table `pilihan_destinasi`
--

CREATE TABLE IF NOT EXISTS `pilihan_destinasi` (
  `id_pilihan_destinasi` int(11) NOT NULL,
  `id_destinasi1` int(11) NOT NULL,
  `id_destinasi2` int(11) NOT NULL,
  `id_destinasi3` int(11) NOT NULL,
  `id_destinasi4` int(11) NOT NULL,
  `id_destinasi5` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pilihan_destinasi`
--

INSERT INTO `pilihan_destinasi` (`id_pilihan_destinasi`, `id_destinasi1`, `id_destinasi2`, `id_destinasi3`, `id_destinasi4`, `id_destinasi5`) VALUES
(35, 6, 7, 8, 9, 10),
(36, 11, 12, 14, 15, 17),
(37, 18, 19, 20, 21, 22);

-- --------------------------------------------------------

--
-- Table structure for table `wisatawan`
--

CREATE TABLE IF NOT EXISTS `wisatawan` (
  `id_wisatawan` int(11) NOT NULL,
  `wisatawan1` varchar(100) NOT NULL,
  `wisatawan2` varchar(100) DEFAULT NULL,
  `wisatawan3` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wisatawan`
--

INSERT INTO `wisatawan` (`id_wisatawan`, `wisatawan1`, `wisatawan2`, `wisatawan3`) VALUES
(9, 'Lala', 'Lili', '-'),
(10, 'Lala', 'Lili', '-'),
(11, 'Lala', 'Lili', '-'),
(13, 'Lala', 'Lili', '-'),
(14, 'Lala', 'Lili', '-'),
(15, 'Alia', 'Kaka', '-');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`), ADD UNIQUE KEY `username` (`username`), ADD UNIQUE KEY `username_2` (`username`);

--
-- Indexes for table `destinasi`
--
ALTER TABLE `destinasi`
  ADD PRIMARY KEY (`id_destinasi`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id_member`), ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `paket`
--
ALTER TABLE `paket`
  ADD PRIMARY KEY (`id_paket`);

--
-- Indexes for table `pemesanan`
--
ALTER TABLE `pemesanan`
  ADD PRIMARY KEY (`id_pesan`), ADD KEY `id_paket` (`id_paket`), ADD KEY `id_paket_2` (`id_paket`);

--
-- Indexes for table `pilihan_destinasi`
--
ALTER TABLE `pilihan_destinasi`
  ADD PRIMARY KEY (`id_pilihan_destinasi`);

--
-- Indexes for table `wisatawan`
--
ALTER TABLE `wisatawan`
  ADD PRIMARY KEY (`id_wisatawan`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `destinasi`
--
ALTER TABLE `destinasi`
  MODIFY `id_destinasi` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `id_member` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `paket`
--
ALTER TABLE `paket`
  MODIFY `id_paket` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `pemesanan`
--
ALTER TABLE `pemesanan`
  MODIFY `id_pesan` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pilihan_destinasi`
--
ALTER TABLE `pilihan_destinasi`
  MODIFY `id_pilihan_destinasi` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `wisatawan`
--
ALTER TABLE `wisatawan`
  MODIFY `id_wisatawan` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
